import React from 'react';
import { analyzeVideoContent } from '../services/geminiService';
import { AnalysisMode, Participant } from '../types';
import { 
  Settings2, 
  Loader2, 
  Brain, 
  ShieldCheck,
  Target,
  Zap,
  Users,
  User,
  Activity,
  ClipboardList,
  FileUp,
  Gavel,
  BarChart3,
  Search,
  Globe,
  Binary,
  Flame,
  Coins,
  Monitor,
  Scale,
  MessageSquare,
  ShieldAlert,
  Verified,
  History,
  Youtube,
  Instagram,
  AlertCircle,
  GraduationCap
} from 'lucide-react';

const COUNTRIES = ['Global', 'USA', 'China', 'European Union', 'United Kingdom', 'India', 'Japan', 'Brazil'];
const YEARS = ['2020', '2022', '2024', '2026', '2030'];
const DEMOGRAPHICS = ['Universal', 'Experts', 'Policy Makers', 'Gen Z', 'Millennials', 'General Public'];
const PERSONAS = ['Scientific Peer Reviewer', 'Supreme Court Justice', 'Fact Checker', 'Neutral Arbiter'];
const INTENTS = ['Professional', 'Entertainment', 'Academic', 'Casual', 'Political'];
const LOGIC_STYLES = ['Elite Peer Review', 'Common Sense', 'Factual Rigor', 'Philosophical Consistency'];
const STAKEHOLDER_MODES = ['Expert-to-Expert', 'Expert-to-Public', 'Peer-to-Peer'];

export const AnalysisStudio: React.FC = () => {
  const [analysisMode, setAnalysisMode] = React.useState<AnalysisMode>(AnalysisMode.ARENA);
  const [video, setVideo] = React.useState<string | null>(null);
  const [videoMime, setVideoMime] = React.useState('');
  const [youtubeUrl, setYoutubeUrl] = React.useState('');
  const [loading, setLoading] = React.useState(false);
  const [result, setResult] = React.useState('');
  const [error, setError] = React.useState<string | null>(null);

  // Calibration State
  const [country, setCountry] = React.useState('Global');
  const [year, setYear] = React.useState('2024');
  const [demography, setDemography] = React.useState('Experts');
  const [persona, setPersona] = React.useState('Scientific Peer Reviewer');
  const [intent, setIntent] = React.useState('Professional');
  const [logicStyle, setLogicStyle] = React.useState('Elite Peer Review');
  const [stakeholderMode, setStakeholderMode] = React.useState('Expert-to-Public');
  const [marginOfError, setMarginOfError] = React.useState(15);
  
  // Weights State
  const [weights, setWeights] = React.useState({ logic: 70, evidence: 60, rhetoric: 40 });
  const [soundEnabled, setSoundEnabled] = React.useState(true);
  
  // RAG State
  const [ragUrls, setRagUrls] = React.useState('https://ipcc.ch/report/\nhttps://fbref.com/en/');
  const [systemPrompt, setSystemPrompt] = React.useState('Prioritize structural validity and empirical density.');
  const [contextFiles, setContextFiles] = React.useState<string[]>([]);
  
  // Participants State
  const [pA, setPA] = React.useState<Participant>({
    name: 'Alpha Proponent',
    vector: 'Economic Efficiency',
    socialUrl: '@alpha_logic',
    followers: '1.2M',
    level: 8,
    thumbnail: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=100&h=100&fit=crop'
  });
  const [pB, setPB] = React.useState<Participant>({
    name: 'Beta Skeptic',
    vector: 'Social Equity',
    socialUrl: '@beta_truth',
    followers: '850K',
    level: 6,
    thumbnail: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop'
  });

  const [arenaStats, setArenaStats] = React.useState({
    pointsA: 0, pointsB: 0, truthPot: '$0', followersA: '+0', followersB: '+0', award: 'Analyzing...'
  });

  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const contextInputRef = React.useRef<HTMLInputElement>(null);

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setVideoMime(file.type);
      const reader = new FileReader();
      reader.onloadend = () => setVideo(reader.result as string);
      reader.readAsDataURL(file);
      setYoutubeUrl('');
    }
  };

  const handleContextUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) setContextFiles(prev => [...prev, file.name]);
  };

  const parseStats = (text: string) => {
    const pA = text.match(/POINTS_A:\s*(\d+)/i)?.[1] || '0';
    const pB = text.match(/POINTS_B:\s*(\d+)/i)?.[1] || '0';
    const pot = text.match(/TRUTH_POT:\s*(\$\d+)/i)?.[1] || '$0';
    const fA = text.match(/FOLLOWERS_A:\s*(\+\d+)/i)?.[1] || '+0';
    const fB = text.match(/FOLLOWERS_B:\s*(\+\d+)/i)?.[1] || '+0';
    const aw = text.match(/AWARD:\s*(.+)/i)?.[1] || 'Pending';
    setArenaStats({ pointsA: parseInt(pA), pointsB: parseInt(pB), truthPot: pot, followersA: fA, followersB: fB, award: aw });
  };

  const runAnalysis = async () => {
    setLoading(true);
    setError(null);
    try {
      const base64 = video ? video.split(',')[1] : null;
      const res = await analyzeVideoContent(base64, videoMime, "Execute WTS adjudication.", {
        mode: analysisMode,
        participantA: pA,
        participantB: analysisMode === AnalysisMode.ARENA ? pB : undefined,
        weights,
        ragUrls: ragUrls.split('\n').filter(Boolean),
        contextFiles,
        systemInstruction: systemPrompt,
        calibration: { country, year, demography, persona, intent, logicStyle, stakeholderMode, marginOfError }
      });
      setResult(res);
      parseStats(res);
      if (soundEnabled) new Audio('https://actions.google.com/sounds/v1/alarms/beep_short.ogg').play().catch(() => {});
    } catch (err: any) {
      setError(err.message || "Analysis fault.");
    } finally {
      setLoading(false);
    }
  };

  const reliability = result.match(/Reliability Rating:\s*(\d+)%/i)?.[1] || '0';

  return (
    <div className="flex flex-col h-full bg-slate-50 text-slate-800 dark:bg-slate-950 dark:text-slate-100 overflow-hidden">
      
      {/* 1. Scoreboard Header */}
      <header className="shrink-0 bg-white/90 border-b border-slate-200 dark:bg-slate-900/50 dark:border-white/5 px-6 py-4 backdrop-blur-md z-30">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8 max-w-[1600px] mx-auto">
          
          {/* Participant A Profile */}
          <div className="flex items-center gap-4 w-full md:w-1/3">
            <div className="relative shrink-0">
              <img src={pA.thumbnail} className="w-14 h-14 rounded-full object-cover ring-2 ring-indigo-500/20" alt="pA" />
              <div className="absolute -bottom-1 -right-1 bg-indigo-600 text-white text-[8px] font-black px-1 rounded shadow">LVL {pA.level}</div>
            </div>
            <div className="flex-1 min-w-0">
               <div className="flex items-center justify-between mb-1">
                 <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 truncate mr-2">{pA.name}</span>
                 <span className="text-xs font-black text-indigo-600 shrink-0">{arenaStats.pointsA} PTS</span>
               </div>
               <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden dark:bg-slate-800">
                  <div className="h-full bg-indigo-500 transition-all duration-1000" style={{ width: `${arenaStats.pointsA}%` }} />
               </div>
               <div className="flex justify-between items-center mt-1 text-[8px] font-bold text-slate-400">
                  <span className="flex items-center gap-1"><Youtube className="w-2 h-2" /> {pA.socialUrl}</span>
                  <span className="text-indigo-500 font-black">{arenaStats.followersA} FOLLOWERS</span>
               </div>
            </div>
          </div>

          {/* Center: Match Meta & Truth Pot */}
          <div className="flex flex-col items-center gap-1 w-full md:w-1/4">
            <div className="flex items-center gap-3">
               <div className="text-center">
                  <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Truth Pot</span>
                  <span className="text-xl font-black text-amber-600 flex items-center justify-center gap-1"><Coins className="w-4 h-4" /> {arenaStats.truthPot}</span>
               </div>
               <div className="w-px h-8 bg-slate-200 dark:bg-white/5 mx-2" />
               <div className="flex flex-col items-center">
                  <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Analysis Mode</span>
                  <div className="flex bg-slate-100 dark:bg-slate-800 rounded-lg p-0.5 mt-1 border border-slate-200 dark:border-white/5">
                    <button onClick={() => setAnalysisMode(AnalysisMode.ARENA)} className={`px-2 py-1 rounded text-[8px] font-black uppercase transition-all ${analysisMode === AnalysisMode.ARENA ? 'bg-indigo-600 text-white' : 'text-slate-400'}`}>Arena</button>
                    <button onClick={() => setAnalysisMode(AnalysisMode.MONOLOGUE)} className={`px-2 py-1 rounded text-[8px] font-black uppercase transition-all ${analysisMode === AnalysisMode.MONOLOGUE ? 'bg-indigo-600 text-white' : 'text-slate-400'}`}>Solo</button>
                  </div>
               </div>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1 bg-indigo-500/10 rounded-full border border-indigo-500/20 mt-1">
               <span className="text-[8px] font-black text-indigo-500 uppercase tracking-widest">{arenaStats.award}</span>
            </div>
          </div>

          {/* Participant B / Baseline Profile */}
          <div className="flex items-center gap-4 w-full md:w-1/3 flex-row-reverse text-right">
            <div className="relative shrink-0">
              {analysisMode === AnalysisMode.ARENA ? (
                <img src={pB.thumbnail} className="w-14 h-14 rounded-full object-cover ring-2 ring-red-500/20" alt="pB" />
              ) : (
                <div className="w-14 h-14 rounded-full bg-emerald-500/10 flex items-center justify-center border-2 border-emerald-500/20"><ShieldCheck className="w-8 h-8 text-emerald-500" /></div>
              )}
              <div className="absolute -bottom-1 -left-1 bg-red-600 text-white text-[8px] font-black px-1 rounded shadow">
                {analysisMode === AnalysisMode.ARENA ? `LVL ${pB.level}` : 'TRUTH'}
              </div>
            </div>
            <div className="flex-1 min-w-0">
               <div className="flex items-center justify-between mb-1 flex-row-reverse">
                 <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 truncate ml-2">
                  {analysisMode === AnalysisMode.ARENA ? pB.name : 'FACTUAL BASELINE'}
                 </span>
                 <span className={`text-xs font-black shrink-0 ${analysisMode === AnalysisMode.ARENA ? 'text-red-600' : 'text-emerald-500'}`}>{arenaStats.pointsB} PTS</span>
               </div>
               <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden flex flex-row-reverse dark:bg-slate-800">
                  <div className={`h-full ${analysisMode === AnalysisMode.ARENA ? 'bg-red-500' : 'bg-emerald-500'} transition-all duration-1000`} style={{ width: `${arenaStats.pointsB}%` }} />
               </div>
               <div className="flex justify-between items-center mt-1 text-[8px] font-bold text-slate-400 flex-row-reverse">
                  <span className="flex items-center gap-1">
                    {analysisMode === AnalysisMode.ARENA ? <><Instagram className="w-2 h-2" /> {pB.socialUrl}</> : <><Binary className="w-2 h-2" /> Truth Matrix</>}
                  </span>
                  <span className={analysisMode === AnalysisMode.ARENA ? 'text-red-500 font-black' : 'text-emerald-500 font-black'}>
                    {analysisMode === AnalysisMode.ARENA ? `${arenaStats.followersB} FOLLOWERS` : 'VERIFIED DATA'}
                  </span>
               </div>
            </div>
          </div>

        </div>
      </header>

      {/* 2. Main Sidebar & Workspace */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        
        {/* Left: Deep Calibration & RAG Tools */}
        <aside className="w-full lg:w-80 shrink-0 border-r border-slate-200 bg-white dark:bg-slate-900/30 dark:border-white/5 overflow-y-auto p-5 space-y-6 no-scrollbar">
          
          {/* Proponent Profiles Editor */}
          <div className="space-y-4">
             {/* Fixed: Replaced non-existent UsersIcon with Users */}
             <div className="flex items-center gap-2 mb-2"><Users className="w-4 h-4 text-indigo-600" /><h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Proponent Config</h3></div>
             
             <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-white/5 space-y-3">
               <div className="flex items-center justify-between"><span className="text-[9px] font-black text-indigo-500 uppercase">Subject A / Proponent</span><Youtube className="w-3 h-3 text-red-600" /></div>
               <input value={pA.name} onChange={e => setPA({...pA, name: e.target.value})} className="w-full text-xs font-bold bg-transparent border-b border-slate-200 dark:border-white/10 outline-none pb-1" />
               <input value={pA.socialUrl} onChange={e => setPA({...pA, socialUrl: e.target.value})} className="w-full text-[10px] bg-transparent outline-none text-slate-400 font-mono" placeholder="@handle" />
               <div className="flex gap-2">
                 <div className="flex-1 bg-white dark:bg-slate-900 rounded p-1.5 border border-slate-200 dark:border-white/5">
                   <label className="text-[8px] block font-black text-slate-400 uppercase">Followers</label>
                   <input value={pA.followers} onChange={e => setPA({...pA, followers: e.target.value})} className="w-full text-[10px] font-bold bg-transparent outline-none" />
                 </div>
                 <div className="w-16 bg-white dark:bg-slate-900 rounded p-1.5 border border-slate-200 dark:border-white/5">
                   <label className="text-[8px] block font-black text-slate-400 uppercase">Rank</label>
                   <input type="number" value={pA.level} onChange={e => setPA({...pA, level: parseInt(e.target.value)})} className="w-full text-[10px] font-bold bg-transparent outline-none" />
                 </div>
               </div>
             </div>

             {analysisMode === AnalysisMode.ARENA && (
               <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-white/5 space-y-3">
                 <div className="flex items-center justify-between"><span className="text-[9px] font-black text-red-500 uppercase">Subject B / Adversary</span><Instagram className="w-3 h-3 text-pink-600" /></div>
                 <input value={pB.name} onChange={e => setPB({...pB, name: e.target.value})} className="w-full text-xs font-bold bg-transparent border-b border-slate-200 dark:border-white/10 outline-none pb-1" />
                 <input value={pB.socialUrl} onChange={e => setPB({...pB, socialUrl: e.target.value})} className="w-full text-[10px] bg-transparent outline-none text-slate-400 font-mono" placeholder="@handle" />
                 <div className="flex gap-2">
                   <div className="flex-1 bg-white dark:bg-slate-900 rounded p-1.5 border border-slate-200 dark:border-white/5">
                     <label className="text-[8px] block font-black text-slate-400 uppercase">Followers</label>
                     <input value={pB.followers} onChange={e => setPB({...pB, followers: e.target.value})} className="w-full text-[10px] font-bold bg-transparent outline-none" />
                   </div>
                   <div className="w-16 bg-white dark:bg-slate-900 rounded p-1.5 border border-slate-200 dark:border-white/5">
                     <label className="text-[8px] block font-black text-slate-400 uppercase">Rank</label>
                     <input type="number" value={pB.level} onChange={e => setPB({...pB, level: parseInt(e.target.value)})} className="w-full text-[10px] font-bold bg-transparent outline-none" />
                   </div>
                 </div>
               </div>
             )}
          </div>

          {/* Deep Calibration */}
          <div className="pt-4 border-t border-slate-200 dark:border-white/5 space-y-4">
             <div className="flex items-center gap-2 mb-2"><Globe className="w-4 h-4 text-indigo-600" /><h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Global Calibration</h3></div>
             <div className="grid grid-cols-2 gap-2">
               <select value={country} onChange={e => setCountry(e.target.value)} className="w-full text-[10px] bg-slate-50 border border-slate-200 rounded-lg p-2 dark:bg-slate-800/50 dark:border-white/10">{COUNTRIES.map(c => <option key={c} value={c}>{c}</option>)}</select>
               <select value={year} onChange={e => setYear(e.target.value)} className="w-full text-[10px] bg-slate-50 border border-slate-200 rounded-lg p-2 dark:bg-slate-800/50 dark:border-white/10">{YEARS.map(y => <option key={y} value={y}>{y}</option>)}</select>
             </div>
             <div className="space-y-4">
                <div className="space-y-1"><label className="text-[9px] font-black text-slate-500 uppercase">Judge Persona</label><select value={persona} onChange={e => setPersona(e.target.value)} className="w-full text-[10px] bg-slate-50 border border-slate-200 rounded-lg p-2 dark:bg-slate-800/50 dark:border-white/10">{PERSONAS.map(p => <option key={p} value={p}>{p}</option>)}</select></div>
                <div className="space-y-1"><label className="text-[9px] font-black text-slate-500 uppercase">Stakeholder Mode</label><select value={stakeholderMode} onChange={e => setStakeholderMode(e.target.value)} className="w-full text-[10px] bg-slate-50 border border-slate-200 rounded-lg p-2 dark:bg-slate-800/50 dark:border-white/10">{STAKEHOLDER_MODES.map(m => <option key={m} value={m}>{m}</option>)}</select></div>
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-[9px] font-black text-slate-500 uppercase"><span>Margin of Error</span><span>{marginOfError}%</span></div>
                  <input type="range" min="0" max="100" step="5" value={marginOfError} onChange={e => setMarginOfError(parseInt(e.target.value))} className="w-full h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600" />
                </div>
             </div>
          </div>

          {/* RAG Tools */}
          <div className="pt-4 border-t border-slate-200 dark:border-white/5 space-y-4">
             <div className="flex items-center gap-2 mb-2"><ClipboardList className="w-4 h-4 text-indigo-600" /><h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Neural RAG binding</h3></div>
             <textarea value={ragUrls} onChange={e => setRagUrls(e.target.value)} className="w-full bg-slate-50 text-[10px] font-mono border border-slate-200 rounded-lg p-2 h-20 outline-none dark:bg-white/5 dark:border-white/10" placeholder="Source URLs (one per line)..." />
             <div onClick={() => contextInputRef.current?.click()} className="p-3 border-2 border-dashed border-slate-200 rounded-lg bg-slate-50 hover:bg-slate-100 transition-all flex flex-col items-center justify-center cursor-pointer group dark:bg-white/5 dark:border-white/10">
                <FileUp className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 mb-1" />
                <span className="text-[9px] font-bold text-slate-500">Inject Context Files</span>
                <input ref={contextInputRef} type="file" className="hidden" onChange={handleContextUpload} />
             </div>
          </div>

        </aside>

        {/* Main Feed Workspace */}
        <main className="flex-1 flex flex-col min-w-0 p-6 space-y-6 overflow-y-auto no-scrollbar">
          
          <div className="grid lg:grid-cols-[1fr_350px] gap-6">
            <div className="space-y-6">
               <div className="bg-white dark:bg-slate-900/30 rounded-3xl border border-slate-200 dark:border-white/5 p-6 shadow-sm relative overflow-hidden">
                  <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                    <div className="space-y-3">
                       <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2"><Monitor className="w-3 h-3" /> Input Source</h4>
                       <div onClick={() => fileInputRef.current?.click()} className="aspect-video bg-slate-100 dark:bg-black/50 rounded-2xl border border-slate-200 dark:border-white/10 flex flex-col items-center justify-center cursor-pointer hover:border-indigo-500/30 transition-all overflow-hidden relative shadow-lg">
                         {video ? <video src={video} className="w-full h-full object-contain" controls /> : (
                           <><div className="w-12 h-12 bg-white dark:bg-white/5 rounded-full shadow-md flex items-center justify-center mb-2"><History className="w-5 h-5 text-indigo-600" /></div><p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Neural Simulation Data</p></>
                         )}
                         <input ref={fileInputRef} type="file" className="hidden" accept="video/*" onChange={handleVideoUpload} />
                       </div>
                    </div>
                    <div className="flex flex-col gap-4">
                       <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2"><Gavel className="w-3.5 h-3.5 text-indigo-600" /> Adjudication Parameters</h4>
                       <textarea value={systemPrompt} onChange={e => setSystemPrompt(e.target.value)} className="flex-1 w-full bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-2xl p-4 text-[11px] font-medium leading-relaxed outline-none focus:ring-2 focus:ring-indigo-500 resize-none min-h-[120px]" />
                       <button onClick={runAnalysis} disabled={loading} className="w-full bg-indigo-600 hover:bg-indigo-700 text-white flex items-center justify-center gap-3 py-4 rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-lg active:scale-[0.98] transition-all disabled:opacity-50">
                         {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <ShieldCheck className="w-5 h-5" />} Execute WTS Logic
                       </button>
                    </div>
                  </div>
               </div>

               <div className="bg-white dark:bg-slate-900/30 rounded-3xl border border-slate-200 dark:border-white/5 flex flex-col overflow-hidden min-h-[450px] shadow-sm">
                  <div className="px-6 py-4 border-b border-slate-100 dark:border-white/5 bg-slate-50 dark:bg-white/5 flex justify-between items-center">
                     <div className="flex items-center gap-2"><BarChart3 className="w-4 h-4 text-indigo-600" /><h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Logic Adjudication (v5)</h3></div>
                     <span className="text-[8px] font-black bg-green-500/10 text-green-600 px-3 py-1 rounded-full border border-green-500/20 uppercase tracking-widest">Truth Index: {reliability}%</span>
                  </div>
                  <div className="flex-1 p-8 font-mono text-[11px] text-slate-700 dark:text-slate-300 leading-relaxed overflow-y-auto no-scrollbar">
                    {loading ? (
                       <div className="h-full flex flex-col items-center justify-center gap-6"><Brain className="w-16 h-16 animate-pulse text-indigo-500" /><p className="text-[10px] font-black uppercase tracking-[0.4em] text-indigo-600">Executing Syllogistic Audit</p></div>
                    ) : result ? (
                       <div className="prose prose-slate prose-xs max-w-none dark:prose-invert">
                         {result.split(/POINTS_A|POINTS_B|TRUTH_POT|FOLLOWERS_A|FOLLOWERS_B|AWARD/)[0]}
                         <div className="mt-8 pt-8 border-t border-slate-100 dark:border-white/5">{result.substring(result.indexOf('Verdict:'))}</div>
                       </div>
                    ) : (
                       <div className="h-full flex flex-col items-center justify-center gap-4 opacity-20"><Binary className="w-12 h-12 text-slate-500" /><p className="text-[10px] font-black uppercase tracking-widest">Standby for Data Matrix</p></div>
                    )}
                  </div>
               </div>
            </div>

            {/* Right: Active Fallacy Console & Weights */}
            <aside className="space-y-6">
               <div className="bg-white dark:bg-slate-900/50 rounded-3xl border border-slate-200 dark:border-white/5 overflow-hidden flex flex-col h-[300px] shadow-sm">
                  <div className="px-5 py-3 border-b border-slate-100 dark:border-white/5 bg-slate-50 dark:bg-white/5 flex items-center justify-between"><h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-2"><Activity className="w-3 h-3 text-red-500" /> Active Detection</h4><span className="text-[8px] font-black text-red-500 uppercase animate-pulse">Live Audit</span></div>
                  <div className="flex-1 p-4 overflow-y-auto space-y-3 no-scrollbar">
                     {result && result.includes('Fallacy Log') ? result.match(/Fallacy Log:([\s\S]+?)(Reliability Score|Query|$)/)?.[1].split('\n').filter(l => l.trim().length > 5).map((line, i) => (
                        <div key={i} className="flex gap-3 animate-in slide-in-from-right-2 duration-300"><div className="w-1.5 h-1.5 rounded-full bg-red-500 mt-1 shrink-0" /><div className="space-y-0.5"><p className="text-[9px] font-black text-red-500 uppercase">Violation</p><p className="text-[10px] font-medium text-slate-600 dark:text-slate-400 leading-tight">{line.trim().replace(/^[-*]\s*/, '')}</p></div></div>
                     )) : <p className="text-[10px] text-slate-400 italic">No violations detected.</p>}
                  </div>
               </div>

               <div className="bg-white dark:bg-slate-900/50 rounded-3xl border border-slate-200 dark:border-white/5 p-6 space-y-6 shadow-sm">
                  <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2"><Scale className="w-3 h-3 text-indigo-500" /> WTS Calibration</h4>
                  <div className="space-y-6">
                     {[{ label: 'Structural Logic', color: 'indigo', val: weights.logic }, { label: 'Empirical Density', color: 'green', val: weights.evidence }, { label: 'Rhetoric Strategy', color: 'amber', val: weights.rhetoric }].map(m => (
                        <div key={m.label} className="space-y-2">
                           <div className="flex justify-between items-end"><span className="text-[10px] font-black text-slate-400 uppercase tracking-tighter">{m.label}</span><span className={`text-xs font-black text-${m.color}-600`}>{m.val}%</span></div>
                           <div className="w-full h-1 bg-slate-100 rounded-full overflow-hidden dark:bg-slate-800"><div className={`h-full bg-${m.color === 'indigo' ? 'indigo-600' : m.color === 'green' ? 'green-600' : 'amber-600'} transition-all duration-1000`} style={{ width: `${m.val}%` }} /></div>
                        </div>
                     ))}
                  </div>
               </div>
            </aside>
          </div>

          {error && <div className="p-4 bg-red-50 border border-red-100 rounded-2xl flex items-center gap-3 text-red-600 text-[10px] font-black uppercase tracking-widest animate-in fade-in"><AlertCircle className="w-5 h-5" /> Analysis Fault: {error}</div>}
        </main>
      </div>
      
      <style>{`
        .scrollbar-hide::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        .prose-xs { font-size: 0.7rem; line-height: 1.6; }
      `}</style>
    </div>
  );
};