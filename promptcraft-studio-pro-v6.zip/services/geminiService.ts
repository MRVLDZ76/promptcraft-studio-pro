import { GoogleGenAI, Type, Modality } from "@google/genai";
import { PromptState, SequenceSegment, AnalysisMode, Participant } from '../types';

export const polishPrompt = async (state: PromptState, currentPrompt: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `You are an expert prompt engineer. Improve this prompt for maximum visual quality, focusing on lighting, textures, and composition. Keep it as a single coherent paragraph. Original: ${currentPrompt}`,
    config: {
      temperature: 0.8,
      topP: 0.95,
    },
  });
  return response.text?.trim() || currentPrompt;
};

export const generateSequence = async (
  narrative: string, 
  totalSec: number, 
  clipLen: number,
  stylePreference: string = '',
  motionPreference: string = ''
): Promise<SequenceSegment[]> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const count = Math.ceil(totalSec / clipLen);
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Create a detailed cinematic video sequence plan based on this Narrative Arc: "${narrative}".
    Split it into ${count} sequential clips of approximately ${clipLen} seconds each.
    
    Global Style Guidance: ${stylePreference || 'Cinematic, high-fidelity'}
    Preferred Camera Motion: ${motionPreference || 'Dynamic and varied'}

    For each segment, define the action, a specific camera movement (e.g., pan, dolly, tracking), a unique visual style keyword or lighting mood, and a full generation prompt.
    Focus on narrative flow, visual continuity, and high-impact cinematography.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          segments: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.NUMBER },
                seconds: { type: Type.NUMBER },
                action: { type: Type.STRING },
                cameraMovement: { type: Type.STRING, description: "Specific cinematic camera motion for this clip" },
                visualStyle: { type: Type.STRING, description: "Lighting mood or specific visual aesthetic for this clip" },
                prompt: { type: Type.STRING, description: "Detailed generative prompt including subject, action, style, and camera movement" }
              },
              required: ['id', 'seconds', 'action', 'cameraMovement', 'visualStyle', 'prompt']
            }
          }
        },
        required: ['segments']
      }
    }
  });

  const json = JSON.parse(response.text || '{"segments": []}');
  return json.segments;
};

export const editImageWithGemini = async (imageData: string, editPrompt: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        {
          inlineData: {
            data: imageData.split(',')[1],
            mimeType: 'image/png',
          },
        },
        {
          text: editPrompt,
        },
      ],
    },
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      const base64EncodeString: string = part.inlineData.data;
      return `data:image/png;base64,${base64EncodeString}`;
    }
  }
  throw new Error("No image was returned by the model.");
};

export const generateImagePro = async (prompt: string, size: '1K' | '2K' | '4K', aspectRatio: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const validAspects = ["1:1", "3:4", "4:3", "9:16", "16:9"];
  const safeAspect = validAspects.includes(aspectRatio) ? aspectRatio : "1:1";
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-image-preview',
    contents: {
      parts: [{ text: prompt }]
    },
    config: {
      imageConfig: {
        aspectRatio: safeAspect as any,
        imageSize: size
      }
    }
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      const base64EncodeString: string = part.inlineData.data;
      return `data:image/png;base64,${base64EncodeString}`;
    }
  }
  throw new Error("Image generation failed.");
};

export const generateVideoVeo = async (prompt: string, imageBase64?: string, aspect: string = '16:9', resolution: '720p' | '1080p' = '720p'): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const safeAspect = (aspect === '9:16' || aspect === '16:9') ? aspect : '16:9';
  
  let operation = await ai.models.generateVideos({
    model: 'veo-3.1-fast-generate-preview',
    prompt,
    ...(imageBase64 ? {
      image: {
        imageBytes: imageBase64.split(',')[1],
        mimeType: 'image/png',
      }
    } : {}),
    config: {
      numberOfVideos: 1,
      resolution,
      aspectRatio: safeAspect as any
    }
  });

  while (!operation.done) {
    await new Promise(resolve => setTimeout(resolve, 10000));
    operation = await ai.operations.getVideosOperation({ operation: operation });
  }

  const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
  if (!downloadLink) throw new Error("Video generation failed.");
  
  const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
  const blob = await response.blob();
  return URL.createObjectURL(blob);
};

export const generateSpeech = async (text: string, voice: string = 'Zephyr'): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: voice },
        },
      },
    },
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) throw new Error("Speech generation failed.");
  return base64Audio;
};

export const transcribeAudio = async (base64Audio: string, mimeType: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        {
          inlineData: {
            data: base64Audio,
            mimeType: mimeType,
          },
        },
        {
          text: "Please transcribe the provided audio exactly as spoken. Return only the transcription text.",
        },
      ],
    },
  });

  return response.text?.trim() || "Transcription produced no output.";
};

export const analyzeVideoContent = async (
  base64Video: string | null, 
  mimeType: string, 
  userPrompt: string,
  config: {
    mode: AnalysisMode,
    participantA: Participant,
    participantB?: Participant,
    systemInstruction?: string,
    weights: { logic: number, evidence: number, rhetoric: number },
    domain?: string,
    contextFiles?: string[],
    youtubeUrl?: string,
    ragUrls?: string[],
    calibration: {
      country?: string,
      year?: string,
      demography?: string,
      persona?: string,
      intent?: string,
      logicStyle?: string,
      stakeholderMode?: string,
      marginOfError?: number
    }
  }
): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const modeContext = config.mode === AnalysisMode.MONOLOGUE 
    ? `MODE: SOLO MONOLOGUE AUDIT. Compare subject ${config.participantA.name} against the "GLOBAL FACTUAL BASELINE".
       If points B (Truth) > points A, the subject is failing the accuracy threshold.`
    : `MODE: ARENA DEBATE (1v1). Adjudicate Participant A vs Participant B.`;

  const socialMetadata = `
    Subject A Context: [Handle: ${config.participantA.socialUrl}, Followers: ${config.participantA.followers}, Rank: Level ${config.participantA.level}]
    ${config.participantB ? `Subject B Context: [Handle: ${config.participantB.socialUrl}, Followers: ${config.participantB.followers}, Rank: Level ${config.participantB.level}]` : ''}
  `;

  const calibrationSystem = `
    CALIBRATION SETTINGS:
    - Target Region: ${config.calibration.country || 'Global'}
    - Temporal Frame: ${config.calibration.year || '2024'}
    - Demography: ${config.calibration.demography || 'Universal'}
    - Judge Persona: ${config.calibration.persona || 'Neutral Arbiter'}
    - Interaction Style: ${config.calibration.stakeholderMode || 'Expert-to-Public'}
    - Intent: ${config.calibration.intent || 'Professional'}
    - Logic Rigour: ${config.calibration.logicStyle || 'Standard'}
    - Margin of Error: ${config.calibration.marginOfError || 0}% (Allow minor errors if this is > 15%)
  `;

  const weightInfo = `Weighting Schema: Logic Core ${config.weights.logic}%, Evidence Density ${config.weights.evidence}%, Rhetorical Impact ${config.weights.rhetoric}%.`;
  const fileContext = config.contextFiles && config.contextFiles.length > 0 ? `\nInjected RAG Context: ${config.contextFiles.join(', ')}.` : '';
  const urlContext = config.ragUrls && config.ragUrls.length > 0 ? `\nVerified Data Sources: ${config.ragUrls.join(', ')}.` : '';

  const finalPrompt = `
    ${modeContext}
    ${socialMetadata}
    ${calibrationSystem}
    ${weightInfo}
    ${fileContext}
    ${urlContext}
    
    TASK: Execute Adjudication Logic (Weighted Truth Score - WTS).
    
    REQUIRED GAMIFICATION STATS:
    POINTS_A: [0-100]
    POINTS_B: [0-100]
    TRUTH_POT: $[0-10000]
    FOLLOWERS_A: +[Number]
    FOLLOWERS_B: +[Number]
    AWARD: [Title like "Master Syllogist" or "Truth Seeker"]
    
    Structure your output:
    1. Gamification Stats
    2. Final Verdict (with winner declaration based on calibration)
    3. WTS Matrix Breakdown (Logic/Evidence/Rhetoric scores)
    4. Active Detection Fallacy Log
    5. Reliability Rating (%)
    
    Analysis Query: ${userPrompt}
  `;

  const contents: any = { parts: [] };
  if (base64Video) {
    contents.parts.push({ inlineData: { data: base64Video, mimeType: mimeType } });
  }
  contents.parts.push({ text: finalPrompt });

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: contents,
    config: {
      systemInstruction: config.systemInstruction || "You are the Logic Arbiter. Use the provided calibration and social metadata to determine factual reliability and winners.",
    }
  });

  return response.text?.trim() || "Empty analysis.";
};
