import { GoogleGenAI, Type, Modality } from "@google/genai";
import { PromptState, SequenceSegment, AnalysisMode, Participant } from '../types';

export const analyzeVideoContent = async (
  base64Video: string | null, 
  mimeType: string, 
  userPrompt: string,
  config: {
    mode: AnalysisMode,
    participantA: Participant,
    participantB?: Participant,
    systemInstruction?: string,
    weights: { logic: number, evidence: number, rhetoric: number },
    domain?: string,
    contextFiles?: string[],
    youtubeUrl?: string,
    ragUrls?: string[],
    calibration: {
      country?: string,
      year?: string,
      demography?: string,
      persona?: string,
      intent?: string,
      logicStyle?: string,
      stakeholderMode?: string,
      marginOfError?: number
    }
  }
): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  // THE COGNITIVE MOTOR: TOULMIN MODEL & ARGUMENTATIVE DECONSTRUCTION
  const toulminInstructions = `
    DECONSTRUCTION PROTOCOL: Execute analysis via the Toulmin Argumentation Model:
    - CLAIM: Identify the central thesis or conclusion.
    - GROUNDS: Audit the factual data or evidence supporting the claim.
    - WARRANT: Evaluate the logical bridge connecting grounds to claim.
    - BACKING: Verify the authority or theoretical support for the warrant.
    - MODAL QUALIFIER: Assess the degree of certainty/force (e.g., 'always' vs 'presumably').
    - REBUTTAL: Identify counter-arguments or conditions of exception.
  `;

  const modeContext = config.mode === AnalysisMode.MONOLOGUE 
    ? `ANALYSIS PROTOCOL: SOLO AUDIT (The Crystal Box).
       Subject: ${config.participantA.name} [Authority Level: ${config.participantA.level}].
       Objective: Measure subject claims against the "GLOBAL FACTUAL MATRIX" (Truth Matrix).
       Result: If Truth Density > Subject Reliability, declare Factual Bankruptcy.`
    : `ANALYSIS PROTOCOL: ARENA DEBATE (1v1).
       Contest: Participant A vs Participant B.
       Objective: Determine who controls the "Mind Palace" of logic and evidence.`;

  const arbiterIdentity = `
    IDENTITY: You are "THE AI ARBITER". 
    TONE: Analytical, surgical, neutral but firm. Use "Sherlock-style" deduction logic.
    CALIBRATION TARGETS:
    - REGION: ${config.calibration.country}
    - TEMPORAL FRAME: ${config.calibration.year}
    - DEMOGRAPHY: ${config.calibration.demography}
    - JUDGE PERSONA: ${config.calibration.persona}
    - RIGOUR: ${config.calibration.logicStyle}
  `;

  const scoringRubric = `
    WTS MATRIX (Weighted Truth Score):
    - Content/Logic (${config.weights.logic}%): Validity of syllogisms and Toulmin structure.
    - Style/Rhetoric (${config.weights.rhetoric}%): Persuasion, tone, and delivery.
    - Strategy/Evidence (${config.weights.evidence}%): Relevance, grounding, and response to counter-arguments.
    - Margin of Error: ${config.calibration.marginOfError}% allowance.
  `;

  const finalPrompt = `
    ${arbiterIdentity}
    ${modeContext}
    ${toulminInstructions}
    ${scoringRubric}
    
    RAG BINDING: [Files: ${config.contextFiles?.join(', ') || 'None'}, Verified URLs: ${config.ragUrls?.join(', ') || 'None'}]
    
    TASK: Execute Adjudication.
    
    GAMIFICATION DATA (REQUIRED FIRST LINES):
    POINTS_A: [0-100]
    POINTS_B: [0-100]
    TRUTH_POT: $[0-10000]
    FOLLOWERS_A: +[Number]
    FOLLOWERS_B: +[Number]
    AWARD: [Title like "Master of Warrants" or "Fallacy Destroyer"]
    
    DETAILED OUTPUT:
    1. ARBITER VERDICT (Final judgment based on calibration)
    2. TOULMIN MATRIX (Claim-by-claim breakdown)
    3. FALLACY DETECTION (Label violations like Ad Hominem, Strawman, Slippery Slope)
    4. RELIABILITY RATING (%)
    
    USER QUERY: ${userPrompt}
  `;

  const contents: any = { parts: [] };
  if (base64Video) {
    contents.parts.push({ inlineData: { data: base64Video, mimeType: mimeType } });
  }
  contents.parts.push({ text: finalPrompt });

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: contents,
    config: {
      systemInstruction: "You are 'The AI Arbiter'. You perform high-rigour logical analysis using the Toulmin model. You are immune to rhetoric and focused solely on factual density and structural validity.",
    }
  });

  return response.text?.trim() || "Simulation failure: No logic processed.";
};

export const polishPrompt = async (state: PromptState, currentPrompt: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Improve this prompt for visual quality: ${currentPrompt}`,
  });
  return response.text?.trim() || currentPrompt;
};

export const generateSequence = async (n: string, t: number, c: number, s: string = '', m: string = ''): Promise<SequenceSegment[]> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Plan ${Math.ceil(t/c)} clips for: ${n}`,
    config: { responseMimeType: "application/json" }
  });
  return JSON.parse(response.text || '{"segments": []}').segments;
};

export const editImageWithGemini = async (i: string, p: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: { parts: [{ inlineData: { data: i.split(',')[1], mimeType: 'image/png' } }, { text: p }] },
  });
  return `data:image/png;base64,${response.candidates?.[0]?.content?.parts.find(p => p.inlineData)?.inlineData?.data}`;
};

export const generateImagePro = async (p: string, s: '1K' | '2K' | '4K', a: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-image-preview',
    contents: { parts: [{ text: p }] },
    config: { imageConfig: { aspectRatio: a as any, imageSize: s } }
  });
  return `data:image/png;base64,${response.candidates?.[0]?.content?.parts.find(p => p.inlineData)?.inlineData?.data}`;
};

export const generateVideoVeo = async (p: string, i?: string, a: string = '16:9', r: '720p' | '1080p' = '720p'): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  let op = await ai.models.generateVideos({
    model: 'veo-3.1-fast-generate-preview',
    prompt: p,
    ...(i ? { image: { imageBytes: i.split(',')[1], mimeType: 'image/png' } } : {}),
    config: { numberOfVideos: 1, resolution: r, aspectRatio: a as any }
  });
  while (!op.done) {
    await new Promise(r => setTimeout(r, 10000));
    op = await ai.operations.getVideosOperation({ operation: op });
  }
  const link = op.response?.generatedVideos?.[0]?.video?.uri;
  const res = await fetch(`${link}&key=${process.env.API_KEY}`);
  const blob = await res.blob();
  return URL.createObjectURL(blob);
};

export const generateSpeech = async (t: string, v: string = 'Zephyr'): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text: t }] }],
    config: { responseModalities: [Modality.AUDIO], speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: v } } } },
  });
  return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || "";
};

export const transcribeAudio = async (b: string, m: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const res = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: { parts: [{ inlineData: { data: b, mimeType: m } }, { text: "Transcribe exactly." }] },
  });
  return res.text?.trim() || "";
};
