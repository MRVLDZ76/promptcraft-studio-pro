
export enum Mode {
  IMAGE = 'image',
  VIDEO = 'video',
  SEQUENCE = 'sequence',
  EDIT = 'edit',
  AUDIO = 'audio',
  TRANSCRIPTION = 'transcription',
  ANALYSIS = 'analysis'
}

export interface VisualIngredient {
  id: string;
  label: string;
  value: string;
  desc: string;
}

export interface PromptState {
  subject: string;
  negative: string;
  aspect: string;
  model: string;
  imageSize: '1K' | '2K' | '4K';
  style: {
    cam: string;
    light: string[];
    film: string;
  };
  scene: {
    setting: string;
    action: string;
    composition: string;
    mood: string;
    color: string;
  };
  detailLevel: 'compact' | 'detailed' | 'ultra';
  customIngredients: string[];
  video: {
    move: string;
    dur: string;
    resolution: '720p' | '1080p';
  };
}

export interface Character {
  id: string;
  name: string;
  text: string;
}

export interface SequenceSegment {
  id: number;
  seconds: number;
  action: string;
  prompt: string;
  cameraMovement: string;
  visualStyle: string;
}

export interface QAIssue {
  severity: 'warn' | 'info';
  title: string;
  detail: string;
  fixId: string | null;
}
