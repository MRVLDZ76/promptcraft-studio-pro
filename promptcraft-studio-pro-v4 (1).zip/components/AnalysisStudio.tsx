import React from 'react';
import { analyzeVideoContent } from '../services/geminiService';
import { 
  Video, 
  Play, 
  Upload, 
  Settings2, 
  FileText, 
  Link as LinkIcon, 
  Volume2, 
  VolumeX, 
  Loader2, 
  Brain, 
  AlertCircle,
  ShieldCheck,
  Target,
  Zap,
  User,
  Activity,
  ClipboardList,
  FileUp,
  Gavel,
  Trophy,
  BarChart3,
  Search,
  Globe,
  Calendar,
  Users,
  UserCheck,
  Binary,
  Quote,
  Flame,
  Coins,
  Monitor
} from 'lucide-react';

const COUNTRIES = ['Global', 'USA', 'China', 'European Union', 'United Kingdom', 'India', 'Japan', 'Brazil', 'South Africa', 'Middle East'];
const YEARS = ['2020', '2021', '2022', '2023', '2024', '2025', '2026', '2030'];
const DEMOGRAPHICS = ['Universal', 'Experts/Scholars', 'Policy Makers', 'Gen Z (10-25)', 'Millennials (25-40)', 'Gen X/Boomers', 'General Public'];
const PERSONAS = [
  'Scientific Peer Reviewer', 
  'Supreme Court Justice', 
  'Fact Checker / Auditor', 
  'Philosophical Ethicist', 
  'Investigative Journalist',
  'Aggressive Contrarian',
  'Neutral Arbiter'
];

export const AnalysisStudio: React.FC = () => {
  const [video, setVideo] = React.useState<string | null>(null);
  const [videoMime, setVideoMime] = React.useState('');
  const [youtubeUrl, setYoutubeUrl] = React.useState('');
  const [scenarioName, setScenarioName] = React.useState('Neural Simulation: 0042');
  const [prompt, setPrompt] = React.useState('Evaluate the logic core and provide a verdict based on current calibration parameters.');
  const [loading, setLoading] = React.useState(false);
  const [result, setResult] = React.useState('');
  const [error, setError] = React.useState<string | null>(null);

  // Calibration State
  const [domain, setDomain] = React.useState('Economics: Capitalism vs Socialism');
  const [country, setCountry] = React.useState('Global');
  const [year, setYear] = React.useState('2024');
  const [demography, setDemography] = React.useState('Experts/Scholars');
  const [persona, setPersona] = React.useState('Scientific Peer Reviewer');
  
  const [weights, setWeights] = React.useState({ logic: 70, evidence: 60, rhetoric: 40 });
  const [soundEnabled, setSoundEnabled] = React.useState(true);
  
  // RAG State
  const [ragUrls, setRagUrls] = React.useState('https://ipcc.ch/report/\nhttps://fbref.com/en/');
  const [systemPrompt, setSystemPrompt] = React.useState('Prioritize falsifiability and avoid rewarding rhetorical tricks even if they sound persuasive.');
  
  // Participants
  const [participantA, setParticipantA] = React.useState({ name: 'Proponent Alpha', vector: 'Capital Efficiency' });
  const [participantB, setParticipantB] = React.useState({ name: 'Proponent Beta', vector: 'Equitable Distribution' });

  // Gamified Metrics State
  const [arenaStats, setArenaStats] = React.useState({
    pointsA: 0,
    pointsB: 0,
    truthPot: '$0',
    followersA: '+0',
    followersB: '+0',
    award: 'Pending Decision'
  });

  const [contextFiles, setContextFiles] = React.useState<string[]>([]);
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const contextInputRef = React.useRef<HTMLInputElement>(null);

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setVideoMime(file.type);
    const reader = new FileReader();
    reader.onloadend = () => setVideo(reader.result as string);
    reader.readAsDataURL(file);
    setYoutubeUrl('');
  };

  const handleContextFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) setContextFiles(prev => [...prev, file.name]);
  };

  const parseGamifiedStats = (text: string) => {
    const pA = text.match(/POINTS_A:\s*(\d+)/i)?.[1] || '0';
    const pB = text.match(/POINTS_B:\s*(\d+)/i)?.[1] || '0';
    const pot = text.match(/TRUTH_POT:\s*(\$\d+)/i)?.[1] || '$0';
    const fA = text.match(/FOLLOWERS_A:\s*(\+\d+)/i)?.[1] || '+0';
    const fB = text.match(/FOLLOWERS_B:\s*(\+\d+)/i)?.[1] || '+0';
    const aw = text.match(/AWARD:\s*(.+)/i)?.[1] || 'Pending Decision';

    setArenaStats({
      pointsA: parseInt(pA),
      pointsB: parseInt(pB),
      truthPot: pot,
      followersA: fA,
      followersB: fB,
      award: aw
    });
  };

  const runAnalysis = async () => {
    setLoading(true);
    setError(null);
    try {
      const base64 = video ? video.split(',')[1] : null;
      const fullPrompt = `
        Scenario: ${scenarioName}
        Participants: ${participantA.name} [Vector: ${participantA.vector}] vs ${participantB.name} [Vector: ${participantB.vector}]
        
        Refined Prompt: ${prompt}
        
        Additional RAG URLs:
        ${ragUrls}
      `;
      
      const analysis = await analyzeVideoContent(base64, videoMime, fullPrompt, {
        systemInstruction: systemPrompt,
        domain: domain,
        weights: weights,
        contextFiles: contextFiles,
        youtubeUrl: youtubeUrl,
        calibration: { country, year, demography, persona }
      });
      
      setResult(analysis);
      parseGamifiedStats(analysis);
      if (soundEnabled) {
        const audio = new Audio('https://actions.google.com/sounds/v1/alarms/beep_short.ogg');
        audio.play().catch(() => {});
      }
    } catch (err: any) {
      setError(err.message || "Neural analysis failed.");
    } finally {
      setLoading(false);
    }
  };

  const reliabilityScore = result.match(/Reliability Score:\s*(\d+)%/i)?.[1] || '0';

  return (
    <div className="flex flex-col h-full overflow-hidden bg-slate-50 text-slate-800 dark:bg-slate-950 dark:text-slate-100 selection:bg-indigo-500/30">
      
      {/* 1. Cinematic Arena Header / Scoreboard */}
      <header className="shrink-0 bg-white/80 border-b border-slate-200 dark:bg-slate-900/50 dark:border-white/5 px-6 py-4 backdrop-blur-md z-30">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 max-w-[1600px] mx-auto">
          
          {/* Debater A Stats */}
          <div className="flex items-center gap-4 w-full md:w-1/3 group">
            <div className="w-12 h-12 bg-indigo-600/10 border border-indigo-500/20 rounded-full flex items-center justify-center shrink-0 dark:bg-indigo-600/20 dark:border-indigo-500/30">
               <User className="w-6 h-6 text-indigo-500 dark:text-indigo-400" />
            </div>
            <div className="flex-1">
               <div className="flex items-center justify-between mb-1">
                 <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">{participantA.name}</span>
                 <span className="text-xs font-black text-indigo-600 dark:text-indigo-400">{arenaStats.pointsA} PTS</span>
               </div>
               <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden dark:bg-slate-800">
                  <div className="h-full bg-indigo-500 transition-all duration-1000 ease-out" style={{ width: `${arenaStats.pointsA}%` }} />
               </div>
               <div className="flex justify-between items-center mt-1">
                  <span className="text-[9px] font-bold text-slate-400 italic truncate w-32 dark:text-slate-500">{participantA.vector}</span>
                  <span className="text-[9px] font-black text-indigo-500/80">{arenaStats.followersA} FOLLOWERS</span>
               </div>
            </div>
          </div>

          {/* Center: Match Outcome & Truth Pot */}
          <div className="flex flex-col items-center gap-1 w-full md:w-1/4">
            <div className="flex items-center gap-3">
               <div className="flex flex-col items-center">
                  <span className="text-[8px] font-black text-slate-500 uppercase tracking-[0.3em]">Truth Pot</span>
                  <span className="text-xl font-black text-amber-600 dark:text-amber-400 flex items-center gap-1">
                    <Coins className="w-4 h-4" /> {arenaStats.truthPot}
                  </span>
               </div>
               <div className="w-px h-8 bg-slate-200 dark:bg-white/5 mx-2" />
               <div className="flex flex-col items-center">
                  <span className="text-[8px] font-black text-slate-500 uppercase tracking-[0.3em]">Award Status</span>
                  <span className="text-xs font-black text-slate-800 dark:text-white uppercase tracking-tighter text-center">
                    {arenaStats.award}
                  </span>
               </div>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1 bg-indigo-500/10 rounded-full border border-indigo-500/20 mt-1">
               <div className="w-1 h-1 rounded-full bg-indigo-400 animate-ping" />
               <span className="text-[8px] font-black text-indigo-500 uppercase tracking-widest dark:text-indigo-400">Adjudication In Progress</span>
            </div>
          </div>

          {/* Debater B Stats */}
          <div className="flex items-center gap-4 w-full md:w-1/3 flex-row-reverse text-right group">
            <div className="w-12 h-12 bg-red-600/10 border border-red-500/20 rounded-full flex items-center justify-center shrink-0 dark:bg-red-600/20 dark:border-red-500/30">
               <User className="w-6 h-6 text-red-500 dark:text-red-400" />
            </div>
            <div className="flex-1">
               <div className="flex items-center justify-between mb-1 flex-row-reverse">
                 <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">{participantB.name}</span>
                 <span className="text-xs font-black text-red-600 dark:text-red-400">{arenaStats.pointsB} PTS</span>
               </div>
               <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden flex flex-row-reverse dark:bg-slate-800">
                  <div className="h-full bg-red-500 transition-all duration-1000 ease-out" style={{ width: `${arenaStats.pointsB}%` }} />
               </div>
               <div className="flex justify-between items-center mt-1 flex-row-reverse">
                  <span className="text-[9px] font-bold text-slate-400 italic truncate w-32 dark:text-slate-500">{participantB.vector}</span>
                  <span className="text-[9px] font-black text-red-500/80">{arenaStats.followersB} FOLLOWERS</span>
               </div>
            </div>
          </div>

        </div>
      </header>

      {/* 2. Main Workspace Layout (Sidebar + Arena) */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden max-w-[1800px] mx-auto w-full">
        
        {/* Left: Calibration Sidebar */}
        <aside className="w-full lg:w-72 shrink-0 border-r border-slate-200 bg-white dark:border-white/5 dark:bg-slate-900/30 overflow-y-auto no-scrollbar p-6 space-y-6">
          
          <div className="space-y-4">
             <div className="flex items-center gap-2 mb-2">
                <Settings2 className="w-3 h-3 text-indigo-600 dark:text-indigo-500" />
                <h3 className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">Calibration</h3>
             </div>
             
             <div className="grid grid-cols-1 gap-4">
               <div className="space-y-1">
                 <label className="text-[9px] font-black text-slate-500 dark:text-slate-400 uppercase">Scenario Name</label>
                 <input 
                   value={scenarioName} onChange={e => setScenarioName(e.target.value)}
                   className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2 text-slate-800 outline-none focus:ring-1 focus:ring-indigo-500 font-bold dark:bg-slate-800/50 dark:border-white/10 dark:text-slate-200"
                 />
               </div>
               <div className="space-y-1">
                 <label className="text-[9px] font-black text-slate-500 dark:text-slate-400 uppercase">Region / Temporal</label>
                 <div className="grid grid-cols-2 gap-2">
                    <select value={country} onChange={e => setCountry(e.target.value)} className="w-full text-[10px] bg-slate-50 border border-slate-200 rounded-lg p-1.5 text-slate-700 outline-none dark:bg-slate-800/50 dark:border-white/10 dark:text-slate-300">
                      {COUNTRIES.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                    <select value={year} onChange={e => setYear(e.target.value)} className="w-full text-[10px] bg-slate-50 border border-slate-200 rounded-lg p-1.5 text-slate-700 outline-none dark:bg-slate-800/50 dark:border-white/10 dark:text-slate-300">
                      {YEARS.map(y => <option key={y} value={y}>{y}</option>)}
                    </select>
                 </div>
               </div>
               <div className="space-y-1">
                 <label className="text-[9px] font-black text-slate-500 dark:text-slate-400 uppercase">Demography / Persona</label>
                 <div className="grid grid-cols-1 gap-2">
                    <select value={demography} onChange={e => setDemography(e.target.value)} className="w-full text-[10px] bg-slate-50 border border-slate-200 rounded-lg p-1.5 text-slate-700 outline-none dark:bg-slate-800/50 dark:border-white/10 dark:text-slate-300">
                      {DEMOGRAPHICS.map(d => <option key={d} value={d}>{d}</option>)}
                    </select>
                    <select value={persona} onChange={e => setPersona(e.target.value)} className="w-full text-[10px] bg-slate-50 border border-slate-200 rounded-lg p-1.5 text-slate-700 outline-none dark:bg-slate-800/50 dark:border-white/10 dark:text-slate-300">
                      {PERSONAS.map(p => <option key={p} value={p}>{p}</option>)}
                    </select>
                 </div>
               </div>
             </div>
          </div>

          <div className="pt-4 border-t border-slate-200 dark:border-white/5 space-y-4">
             <div className="flex items-center gap-2 mb-2">
                <ClipboardList className="w-3 h-3 text-indigo-600 dark:text-indigo-500" />
                <h3 className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">RAG Engine</h3>
             </div>
             <div className="space-y-3">
                <div className="space-y-1">
                   <label className="text-[9px] font-black text-slate-500 uppercase">Knowledge Binding URLs</label>
                   <textarea 
                     value={ragUrls} onChange={e => setRagUrls(e.target.value)} rows={3}
                     className="w-full text-[9px] bg-slate-50 border border-slate-200 rounded-lg p-2 text-slate-600 font-mono resize-none outline-none focus:ring-1 focus:ring-indigo-500 dark:bg-slate-800/50 dark:border-white/10 dark:text-slate-400"
                     placeholder="https://..."
                   />
                </div>
                <div 
                  onClick={() => contextInputRef.current?.click()}
                  className="p-3 border-2 border-dashed border-slate-200 rounded-lg bg-slate-50 hover:bg-slate-100 transition-all flex flex-col items-center justify-center cursor-pointer group dark:border-white/10 dark:bg-white/5 dark:hover:bg-white/10"
                >
                   <FileUp className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 dark:text-slate-500 dark:group-hover:text-indigo-400 mb-1" />
                   <span className="text-[9px] font-bold text-slate-500 group-hover:text-slate-700 dark:group-hover:text-slate-300">Inject Context Files</span>
                   <input ref={contextInputRef} type="file" className="hidden" onChange={handleContextFileUpload} />
                </div>
                <div className="space-y-1">
                   <label className="text-[9px] font-black text-slate-500 uppercase">System Parameters</label>
                   <textarea 
                     value={systemPrompt} onChange={e => setSystemPrompt(e.target.value)} rows={3}
                     className="w-full text-[9px] bg-slate-50 border border-slate-200 rounded-lg p-2 text-slate-500 italic font-medium leading-relaxed resize-none outline-none dark:bg-slate-800/50 dark:border-white/10 dark:text-slate-400"
                     placeholder="e.g. Prioritize empirical density..."
                   />
                </div>
             </div>
          </div>

          <button 
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`w-full flex items-center justify-between py-2 px-3 rounded-lg text-[9px] font-black transition-all border ${
              soundEnabled ? 'bg-indigo-600/10 border-indigo-200 text-indigo-700 dark:bg-indigo-500/10 dark:border-indigo-500/30 dark:text-indigo-400' : 'bg-slate-50 border-slate-200 text-slate-500 dark:bg-white/5 dark:border-white/10'
            }`}
          >
            Auditory Feedback
            {soundEnabled ? <Zap className="w-3 h-3 fill-current" /> : <VolumeX className="w-3 h-3" />}
          </button>

        </aside>

        {/* 3. The Main Arena Board */}
        <main className="flex-1 flex flex-col min-w-0 p-6 space-y-6 overflow-y-auto no-scrollbar bg-slate-50 dark:bg-slate-950">
          
          <div className="grid lg:grid-cols-[1fr_350px] gap-6 h-full min-h-0">
            
            {/* Feed & Adjudication Row */}
            <div className="flex flex-col gap-6 min-w-0">
               
               {/* Video Injection & Verdict Panel */}
               <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-6 shadow-sm relative overflow-hidden dark:bg-slate-900/30 dark:border-white/5 dark:backdrop-blur-sm">
                  <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-indigo-500 via-transparent to-red-500 opacity-30" />
                  
                  <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                    {/* Media Feed */}
                    <div className="space-y-3">
                       <div className="flex items-center justify-between px-1">
                          <h4 className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest flex items-center gap-2">
                            <Monitor className="w-3 h-3" /> Input Media
                          </h4>
                          <span className="text-[8px] bg-slate-100 px-1.5 py-0.5 rounded text-slate-500 font-bold dark:bg-white/10 dark:text-slate-400">GEMINI_PRO_V3</span>
                       </div>
                       <div 
                         onClick={() => fileInputRef.current?.click()}
                         className="aspect-video bg-slate-100 rounded-2xl border border-slate-200 flex flex-col items-center justify-center cursor-pointer hover:border-indigo-500/30 transition-all group overflow-hidden relative dark:bg-black/50 dark:border-white/10 shadow-lg"
                       >
                         {video ? (
                           <video src={video} className="w-full h-full object-contain" controls onClick={e => e.stopPropagation()} />
                         ) : (
                           <>
                             <div className="w-12 h-12 bg-white rounded-full shadow-md flex items-center justify-center mb-2 group-hover:scale-110 transition-transform dark:bg-white/5 dark:shadow-none">
                               <Play className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                             </div>
                             <p className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">Awaiting Media Injection</p>
                           </>
                         )}
                         <input ref={fileInputRef} type="file" className="hidden" accept="video/*" onChange={handleVideoUpload} />
                       </div>
                       <div className="relative group">
                          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3 h-3 text-slate-400" />
                          <input 
                            value={youtubeUrl} onChange={e => { setYoutubeUrl(e.target.value); if(e.target.value) setVideo(null); }}
                            className="w-full pl-8 pr-4 py-2 bg-slate-100 border border-slate-200 rounded-xl text-[10px] font-bold text-slate-700 outline-none focus:ring-1 focus:ring-indigo-500 dark:bg-white/5 dark:border-white/10 dark:text-slate-300"
                            placeholder="Connect external stream (YouTube URL)..."
                          />
                       </div>
                    </div>

                    {/* Adjudication Controls & Inference */}
                    <div className="flex flex-col gap-4">
                       <div className="flex items-center gap-2">
                          <Gavel className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                          <h4 className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">Inference Core</h4>
                       </div>
                       <textarea 
                         value={prompt} onChange={e => setPrompt(e.target.value)}
                         className="flex-1 w-full bg-slate-100 border border-slate-200 rounded-2xl p-4 text-[11px] font-medium leading-relaxed text-slate-700 outline-none focus:ring-2 focus:ring-indigo-500 shadow-inner resize-none min-h-[120px] dark:bg-white/5 dark:border-white/10 dark:text-slate-200"
                         placeholder="Paste the core debate question or evaluation criteria..."
                       />
                       <button 
                         onClick={runAnalysis}
                         disabled={(!video && !youtubeUrl) || loading}
                         className="w-full bg-indigo-600 hover:bg-indigo-700 text-white flex items-center justify-center gap-3 py-4 rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-lg shadow-indigo-600/20 active:scale-[0.98] transition-all disabled:opacity-50"
                       >
                         {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <ShieldCheck className="w-5 h-5" />}
                         {loading ? 'Analyzing Syllogisms...' : 'Execute Adjudication'}
                       </button>
                    </div>
                  </div>
               </div>

               {/* Result Output Panel */}
               <div className="flex-1 bg-white rounded-3xl border border-slate-200 flex flex-col overflow-hidden min-h-[400px] shadow-sm dark:bg-slate-900/40 dark:border-white/5">
                  <div className="px-6 py-4 border-b border-slate-100 bg-slate-50 flex justify-between items-center dark:border-white/5 dark:bg-white/5">
                     <div className="flex items-center gap-2">
                        <BarChart3 className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                        <h3 className="text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-widest">Logic Core Result</h3>
                     </div>
                     <div className="flex items-center gap-4">
                        <div className="flex items-center gap-1.5 px-3 py-1 bg-green-500/10 rounded-full border border-green-500/20">
                           <span className="text-[8px] font-black text-green-600 uppercase tracking-widest dark:text-green-500">Truth Score: {reliabilityScore}%</span>
                        </div>
                        <button className="text-slate-400 hover:text-indigo-600 transition-colors">
                           <Trophy className="w-4 h-4" />
                        </button>
                     </div>
                  </div>
                  <div className="flex-1 p-8 font-mono text-[11px] text-slate-700 leading-relaxed overflow-y-auto no-scrollbar selection:bg-indigo-600/50 dark:text-slate-300">
                    {loading ? (
                       <div className="h-full flex flex-col items-center justify-center gap-6 opacity-60">
                          <Brain className="w-16 h-16 animate-pulse text-indigo-500" />
                          <div className="space-y-3 text-center">
                             <p className="text-[10px] font-black uppercase tracking-[0.4em] text-indigo-600 dark:text-indigo-400">Mapping Neural Syllogisms</p>
                             <div className="flex justify-center gap-1.5">
                                {[1,2,3,4,5].map(i => <div key={i} className={`w-1.5 h-1.5 rounded-full bg-indigo-500 animate-bounce [animation-delay:${i*0.2}s]`} />)}
                             </div>
                          </div>
                       </div>
                    ) : result ? (
                       <div className="prose prose-slate prose-xs max-w-none dark:prose-invert">
                         {result.split(/POINTS_A|POINTS_B|TRUTH_POT|FOLLOWERS_A|FOLLOWERS_B|AWARD/)[0]}
                         <div className="mt-8 pt-8 border-t border-slate-100 dark:border-white/5">
                            {result.substring(result.indexOf('Verdict:'))}
                         </div>
                       </div>
                    ) : (
                       <div className="h-full flex flex-col items-center justify-center gap-4 opacity-20">
                          <Binary className="w-12 h-12 text-slate-500" />
                          <p className="text-[10px] font-black uppercase tracking-widest text-slate-500">Adjudication Result Standby</p>
                       </div>
                    )}
                  </div>
               </div>

            </div>

            {/* Right: Active Detection & Scoring Log */}
            <aside className="space-y-6">
               
               {/* 4. Active Detection Console */}
               <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden flex flex-col h-[300px] shadow-sm dark:bg-slate-900/50 dark:border-white/5">
                  <div className="px-5 py-3 border-b border-slate-100 bg-slate-50 flex items-center justify-between dark:border-white/5 dark:bg-white/5">
                     <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-2 dark:text-slate-400">
                        <Activity className="w-3 h-3 text-red-500" /> Active Detection
                     </h4>
                     <span className="text-[8px] font-black text-red-500/80 uppercase animate-pulse">Scanning...</span>
                  </div>
                  <div className="flex-1 p-4 overflow-y-auto space-y-3 no-scrollbar">
                     <div className="flex items-start gap-3">
                        <div className="w-1.5 h-1.5 rounded-full bg-slate-300 mt-1 shrink-0 dark:bg-slate-700" />
                        <div className="space-y-1">
                           <p className="text-[9px] font-black text-slate-400 uppercase tracking-tighter">Match Outcome</p>
                           <p className="text-[10px] font-bold text-slate-600 dark:text-slate-400">
                             {result ? 'Detailed exchange analyzed.' : 'Awaiting first exchange...'}
                           </p>
                        </div>
                     </div>
                     {/* Dynamic logs can go here */}
                     {result && result.includes('Fallacy Log') && (
                        <div className="pt-2 border-t border-slate-100 dark:border-white/5 space-y-4">
                           {result.match(/Fallacy Log:([\s\S]+?)(Reliability Score|Query|$)/)?.[1]
                              .split('\n')
                              .filter(l => l.trim().length > 5)
                              .map((line, i) => (
                                 <div key={i} className="flex gap-3 group animate-in slide-in-from-right-2 duration-300" style={{ animationDelay: `${i*100}ms` }}>
                                    <div className="w-1.5 h-1.5 rounded-full bg-red-500 mt-1 shrink-0 group-hover:scale-125 transition-transform" />
                                    <div className="space-y-0.5">
                                       <p className="text-[9px] font-black text-red-500/80 uppercase">Fallacy Violation</p>
                                       <p className="text-[10px] font-medium text-slate-600 leading-tight dark:text-slate-300">{line.trim().replace(/^[-*]\s*/, '')}</p>
                                    </div>
                                 </div>
                              ))}
                        </div>
                     )}
                  </div>
               </div>

               {/* 5. Syllogistic Scoring (WTS Gauges) */}
               <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-6 shadow-sm dark:bg-slate-900/50 dark:border-white/5">
                  <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2 dark:text-slate-500">
                     <Target className="w-3 h-3 text-indigo-500" /> Neural WTS Matrix
                  </h4>
                  <div className="space-y-6">
                     {[
                        { label: 'Structural Logic', color: 'indigo', val: weights.logic },
                        { label: 'Empirical Density', color: 'green', val: weights.evidence },
                        { label: 'Rhetorical Variance', color: 'amber', val: weights.rhetoric },
                     ].map(m => (
                        <div key={m.label} className="space-y-2">
                           <div className="flex justify-between items-end">
                              <span className="text-[10px] font-black text-slate-400 uppercase tracking-tighter dark:text-slate-500">{m.label}</span>
                              <span className={`text-xs font-black ${m.color === 'indigo' ? 'text-indigo-600' : m.color === 'green' ? 'text-green-600' : 'text-amber-600'} dark:text-${m.color}-400`}>{m.val}%</span>
                           </div>
                           <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden dark:bg-slate-800">
                              <div className={`h-full ${m.color === 'indigo' ? 'bg-indigo-600' : m.color === 'green' ? 'bg-green-600' : 'bg-amber-600'} transition-all duration-1000 ease-out`} style={{ width: `${m.val}%` }} />
                           </div>
                        </div>
                     ))}
                  </div>
               </div>

               {/* 6. Current Arena Leader */}
               <div className="p-6 bg-indigo-50 rounded-3xl border border-indigo-100 flex flex-col items-center text-center space-y-2 shadow-sm dark:bg-gradient-to-br dark:from-indigo-600/20 dark:to-indigo-900/40 dark:border-indigo-500/20">
                  <div className="w-10 h-10 bg-white rounded-full shadow-sm flex items-center justify-center text-indigo-600 dark:bg-indigo-500/20 dark:text-indigo-400">
                     <Flame className="w-5 h-5 fill-current" />
                  </div>
                  <div className="space-y-0.5">
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] dark:text-white">Truth MVP</p>
                    <p className="text-xs font-bold text-slate-800 dark:text-indigo-200">
                      {arenaStats.pointsA > arenaStats.pointsB ? participantA.name : arenaStats.pointsB > arenaStats.pointsA ? participantB.name : 'Stalemate'}
                    </p>
                  </div>
               </div>

            </aside>

          </div>

          {error && (
            <div className="p-4 bg-red-50 border border-red-200 rounded-2xl flex items-center gap-3 text-red-600 text-[10px] font-black uppercase tracking-widest animate-in fade-in slide-in-from-bottom-4 dark:bg-red-900/20 dark:border-red-500/20 dark:text-red-400">
               <AlertCircle className="w-5 h-5" />
               <span>Simulation System Error: {error}</span>
            </div>
          )}

        </main>
      </div>

      <style>{`
        @keyframes loading {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .prose-xs {
           font-size: 0.7rem;
           line-height: 1.6;
        }
      `}</style>
    </div>
  );
};
