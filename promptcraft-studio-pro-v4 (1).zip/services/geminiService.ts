
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { PromptState, SequenceSegment } from '../types';

// Per guidelines: Do not define the model first and call generate content later.
// Per guidelines: Create a new GoogleGenAI instance right before making an API call.

export const polishPrompt = async (state: PromptState, currentPrompt: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `You are an expert prompt engineer. Improve this prompt for maximum visual quality, focusing on lighting, textures, and composition. Keep it as a single coherent paragraph. Original: ${currentPrompt}`,
    config: {
      temperature: 0.8,
      topP: 0.95,
    },
  });
  return response.text?.trim() || currentPrompt;
};

export const generateSequence = async (
  narrative: string, 
  totalSec: number, 
  clipLen: number,
  stylePreference: string = '',
  motionPreference: string = ''
): Promise<SequenceSegment[]> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const count = Math.ceil(totalSec / clipLen);
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Create a detailed cinematic video sequence plan based on this Narrative Arc: "${narrative}".
    Split it into ${count} sequential clips of approximately ${clipLen} seconds each.
    
    Global Style Guidance: ${stylePreference || 'Cinematic, high-fidelity'}
    Preferred Camera Motion: ${motionPreference || 'Dynamic and varied'}

    For each segment, define the action, a specific camera movement (e.g., pan, dolly, tracking), a unique visual style keyword or lighting mood, and a full generation prompt.
    Focus on narrative flow, visual continuity, and high-impact cinematography.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          segments: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.NUMBER },
                seconds: { type: Type.NUMBER },
                action: { type: Type.STRING },
                cameraMovement: { type: Type.STRING, description: "Specific cinematic camera motion for this clip" },
                visualStyle: { type: Type.STRING, description: "Lighting mood or specific visual aesthetic for this clip" },
                prompt: { type: Type.STRING, description: "Detailed generative prompt including subject, action, style, and camera movement" }
              },
              required: ['id', 'seconds', 'action', 'cameraMovement', 'visualStyle', 'prompt']
            }
          }
        },
        required: ['segments']
      }
    }
  });

  const json = JSON.parse(response.text || '{"segments": []}');
  return json.segments;
};

export const editImageWithGemini = async (imageData: string, editPrompt: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        {
          inlineData: {
            data: imageData.split(',')[1],
            mimeType: 'image/png',
          },
        },
        {
          text: editPrompt,
        },
      ],
    },
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      const base64EncodeString: string = part.inlineData.data;
      return `data:image/png;base64,${base64EncodeString}`;
    }
  }
  throw new Error("No image was returned by the model.");
};

export const generateImagePro = async (prompt: string, size: '1K' | '2K' | '4K', aspectRatio: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  // Map provided aspect ratio to supported set: "1:1", "3:4", "4:3", "9:16", and "16:9"
  const validAspects = ["1:1", "3:4", "4:3", "9:16", "16:9"];
  const safeAspect = validAspects.includes(aspectRatio) ? aspectRatio : "1:1";
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-image-preview',
    contents: {
      parts: [{ text: prompt }]
    },
    config: {
      imageConfig: {
        aspectRatio: safeAspect as any,
        imageSize: size
      }
    }
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      const base64EncodeString: string = part.inlineData.data;
      return `data:image/png;base64,${base64EncodeString}`;
    }
  }
  throw new Error("Image generation failed.");
};

export const generateVideoVeo = async (prompt: string, imageBase64?: string, aspect: string = '16:9', resolution: '720p' | '1080p' = '720p'): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const safeAspect = (aspect === '9:16' || aspect === '16:9') ? aspect : '16:9';
  
  let operation = await ai.models.generateVideos({
    model: 'veo-3.1-fast-generate-preview',
    prompt,
    ...(imageBase64 ? {
      image: {
        imageBytes: imageBase64.split(',')[1],
        mimeType: 'image/png',
      }
    } : {}),
    config: {
      numberOfVideos: 1,
      resolution,
      aspectRatio: safeAspect as any
    }
  });

  while (!operation.done) {
    await new Promise(resolve => setTimeout(resolve, 10000));
    operation = await ai.operations.getVideosOperation({ operation: operation });
  }

  const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
  if (!downloadLink) throw new Error("Video generation failed.");
  
  const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
  const blob = await response.blob();
  return URL.createObjectURL(blob);
};

export const generateSpeech = async (text: string, voice: string = 'Zephyr'): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: voice },
        },
      },
    },
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) throw new Error("Speech generation failed.");
  return base64Audio;
};

export const transcribeAudio = async (base64Audio: string, mimeType: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        {
          inlineData: {
            data: base64Audio,
            mimeType: mimeType,
          },
        },
        {
          text: "Please transcribe the provided audio exactly as spoken. Return only the transcription text.",
        },
      ],
    },
  });

  return response.text?.trim() || "Transcription produced no output.";
};

export const analyzeVideoContent = async (
  base64Video: string | null, 
  mimeType: string, 
  userPrompt: string,
  config: {
    systemInstruction?: string,
    weights?: { logic: number, evidence: number, rhetoric: number },
    domain?: string,
    contextFiles?: string[],
    youtubeUrl?: string,
    calibration?: {
      country?: string,
      year?: string,
      demography?: string,
      persona?: string
    }
  }
): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const weightInfo = config.weights ? `Judgement weighting: Structural Validity ${config.weights.logic}%, Empirical Density (Evidence) ${config.weights.evidence}%, Rhetorical Clarity ${config.weights.rhetoric}%.` : '';
  const domainInfo = config.domain ? `Active Scenario: ${config.domain}.` : '';
  const calib = config.calibration ? `Calibration Variables: Country [${config.calibration.country || 'Global'}], Temporal [Year ${config.calibration.year || 'Current'}], Target Demography [${config.calibration.demography || 'Universal'}], Judge Persona [${config.calibration.persona || 'Default Arbiter'}].` : '';
  const fileContext = config.contextFiles && config.contextFiles.length > 0 ? `\n\nBound context files: ${config.contextFiles.join(', ')}.` : '';
  const youtubeContext = config.youtubeUrl ? `\n\nYouTube Source Reference: ${config.youtubeUrl}` : '';

  const finalPrompt = `
    ${domainInfo} 
    ${calib}
    ${weightInfo} 
    ${fileContext}
    ${youtubeContext}
    
    Task: Execute Adjudication Logic (Weighted Truth Score - WTS).
    Distinguish between participants and analyze their exchange under the specified calibration context.
    
    Adjudication Matrix:
    1. Structural Validity (Syllogisms): Identify logical gaps or invalid conclusions based on [Judge Persona].
    2. Empirical Density: Frequency of verifiable data points, citations, and stats relevant to [Year] and [Country].
    3. Fallacy Detection: Scan for logical violations (Ad Hominem, Strawman, etc.).
    
    GAMIFICATION METRICS (REQUIRED):
    At the beginning of your response, provide the following stats in this exact format:
    POINTS_A: [Number 0-100]
    POINTS_B: [Number 0-100]
    TRUTH_POT: $[Number 0-10000]
    FOLLOWERS_A: +[Number]
    FOLLOWERS_B: +[Number]
    AWARD: [Title like "Master Syllogist" or "Pending Decision"]
    
    Required Output Format:
    - GAMIFICATION STATS (as specified above)
    - Verdict: Declare a winner (if a debate) or a Reliability Rating (if a monologue).
    - WTS Breakdown: Logic (x/10), Evidence (x/10), Rhetoric (x/10).
    - Logic Core Output: Summary of structural validity including cultural/temporal nuances from calibration.
    - Fallacy Log: List detected fallacies with short "Active Detection" logs.
    - Reliability Score: Percentage rating trustworthiness.
    
    Query: ${userPrompt}
  `;

  const contents: any = { parts: [] };
  
  if (base64Video) {
    contents.parts.push({
      inlineData: {
        data: base64Video,
        mimeType: mimeType,
      },
    });
  }
  
  contents.parts.push({ text: finalPrompt });

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: contents,
    config: {
      systemInstruction: config.systemInstruction || "You are the Neural Analysis Arena's unbiased logic arbiter. You utilize high-context analysis to score logic, detect fallacies, and map rhetorical strategies.",
    }
  });

  return response.text?.trim() || "No analysis result returned.";
};
