import React from 'react';
import { analyzeVideoContent } from '../services/geminiService';
import { AnalysisMode, Participant } from '../types';
import { 
  Settings2, 
  Loader2, 
  Brain, 
  ShieldCheck,
  Users,
  Activity,
  ClipboardList,
  FileUp,
  Gavel,
  BarChart3,
  Globe,
  Binary,
  Coins,
  Monitor,
  Scale,
  Verified,
  History,
  Youtube,
  Instagram,
  AlertCircle,
  Zap,
  Link as LinkIcon,
  FileText
} from 'lucide-react';

const COUNTRIES = ['Global', 'USA', 'China', 'EU', 'UK', 'India', 'Japan', 'Brazil', 'Spain', 'Mexico'];
const YEARS = ['2020', '2022', '2023', '2024', '2025', '2030'];
const DEMOGRAPHICS = ['Universal', 'Experts / Peer Reviewers', 'Policy Makers', 'Gen Z / Social Media', 'General Public', 'Academic Community'];
const PERSONAS = ['Neutral Arbiter', 'Scientific Peer Reviewer', 'Supreme Court Justice', 'Fact Checker', 'Socratic Inquisitor'];
const LOGIC_STYLES = ['Elite Peer Review', 'Common Sense', 'Factual Rigor', 'Philosophical Consistency', 'Statistical Probability'];
const STAKEHOLDER_MODES = ['Expert-to-Expert', 'Expert-to-Public', 'Peer-to-Peer'];

export const AnalysisStudio: React.FC = () => {
  const [analysisMode, setAnalysisMode] = React.useState<AnalysisMode>(AnalysisMode.ARENA);
  const [video, setVideo] = React.useState<string | null>(null);
  const [videoMime, setVideoMime] = React.useState('');
  const [loading, setLoading] = React.useState(false);
  const [result, setResult] = React.useState('');
  const [error, setError] = React.useState<string | null>(null);
  const [prompt, setPrompt] = React.useState('Evaluate the primary arguments and identify any logical fallacies.');

  // Calibration State
  const [country, setCountry] = React.useState('Global');
  const [year, setYear] = React.useState('2024');
  const [demography, setDemography] = React.useState('Experts / Peer Reviewers');
  const [persona, setPersona] = React.useState('Neutral Arbiter');
  const [logicStyle, setLogicStyle] = React.useState('Elite Peer Review');
  const [stakeholderMode, setStakeholderMode] = React.useState('Expert-to-Public');
  const [marginOfError, setMarginOfError] = React.useState(10);
  
  // Weights State
  const [weights, setWeights] = React.useState({ logic: 40, evidence: 40, rhetoric: 20 });
  const [soundEnabled, setSoundEnabled] = React.useState(true);
  
  // RAG State
  const [ragUrls, setRagUrls] = React.useState('');
  const [systemPrompt, setSystemPrompt] = React.useState('Focus on identifying structural contradictions and evidentiary gaps.');
  const [contextFiles, setContextFiles] = React.useState<string[]>([]);
  
  // Participants State
  const [pA, setPA] = React.useState<Participant>({
    name: 'Proponent Alpha',
    vector: 'Efficiency',
    socialUrl: '@alpha_logic',
    followers: '1.2M',
    level: 8,
    thumbnail: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=100&h=100&fit=crop'
  });
  const [pB, setPB] = React.useState<Participant>({
    name: 'Skeptic Beta',
    vector: 'Ethics',
    socialUrl: '@beta_critique',
    followers: '850K',
    level: 7,
    thumbnail: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop'
  });

  const [arenaStats, setArenaStats] = React.useState({
    pointsA: 0, pointsB: 0, truthPot: '$0', followersA: '+0', followersB: '+0', award: 'Standby'
  });

  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const contextInputRef = React.useRef<HTMLInputElement>(null);

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setVideoMime(file.type);
      const reader = new FileReader();
      reader.onloadend = () => setVideo(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleContextUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      const names = Array.from(files).map(f => f.name);
      setContextFiles(prev => [...prev, ...names]);
    }
  };

  const parseStats = (text: string) => {
    const pA = text.match(/POINTS_A:\s*(\d+)/i)?.[1] || '0';
    const pB = text.match(/POINTS_B:\s*(\d+)/i)?.[1] || '0';
    const pot = text.match(/TRUTH_POT:\s*(\$\d+)/i)?.[1] || '$0';
    const fA = text.match(/FOLLOWERS_A:\s*(\+\d+)/i)?.[1] || '+0';
    const fB = text.match(/FOLLOWERS_B:\s*(\+\d+)/i)?.[1] || '+0';
    const aw = text.match(/AWARD:\s*(.+)/i)?.[1] || 'Awaiting Logic';
    setArenaStats({ pointsA: parseInt(pA), pointsB: parseInt(pB), truthPot: pot, followersA: fA, followersB: fB, award: aw });
  };

  const runAnalysis = async () => {
    setLoading(true);
    setError(null);
    try {
      const base64 = video ? video.split(',')[1] : null;
      const res = await analyzeVideoContent(base64, videoMime, prompt, {
        mode: analysisMode,
        participantA: pA,
        participantB: analysisMode === AnalysisMode.ARENA ? pB : undefined,
        weights,
        ragUrls: ragUrls.split('\n').filter(Boolean),
        contextFiles,
        systemInstruction: systemPrompt,
        calibration: { country, year, demography, persona, logicStyle, stakeholderMode, marginOfError }
      });
      setResult(res);
      parseStats(res);
      if (soundEnabled) {
        const audio = new Audio('https://actions.google.com/sounds/v1/alarms/beep_short.ogg');
        audio.play().catch(() => {});
      }
    } catch (err: any) {
      setError(err.message || "Logic engine failure.");
    } finally {
      setLoading(false);
    }
  };

  const reliability = result.match(/Reliability Rating:\s*(\d+)%/i)?.[1] || '0';

  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 overflow-hidden font-sans">
      
      {/* 1. The Arbiter Scoreboard */}
      <header className="shrink-0 bg-white/90 dark:bg-slate-900/80 border-b border-slate-200 dark:border-indigo-500/20 px-6 py-4 backdrop-blur-xl z-30 shadow-sm">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8 max-w-[1600px] mx-auto">
          
          {/* Proponent A Card */}
          <div className="flex items-center gap-4 w-full md:w-1/3 group">
            <div className="relative shrink-0">
              <img src={pA.thumbnail} className="w-14 h-14 rounded-full object-cover ring-2 ring-indigo-500/20 dark:ring-cyan-500/50 shadow-md dark:shadow-[0_0_15px_rgba(6,182,212,0.3)] transition-all group-hover:scale-105" alt="pA" />
              <div className="absolute -bottom-1 -right-1 bg-indigo-600 dark:bg-cyan-600 text-white text-[8px] font-black px-1.5 rounded-sm shadow-lg border border-white/20">LVL {pA.level}</div>
            </div>
            <div className="flex-1 min-w-0">
               <div className="flex items-center justify-between mb-1">
                 <div className="flex items-center gap-1.5 min-w-0">
                   <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-cyan-400 truncate">{pA.name}</span>
                   <Verified className="w-3 h-3 text-indigo-500 dark:text-cyan-400 shrink-0" />
                 </div>
                 <span className="text-xs font-black text-indigo-600 dark:text-cyan-500">{arenaStats.pointsA} PTS</span>
               </div>
               <div className="w-full h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-indigo-600 dark:bg-cyan-500 transition-all duration-1000 shadow-md" style={{ width: `${arenaStats.pointsA}%` }} />
               </div>
               <div className="flex justify-between items-center mt-1 text-[8px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-tighter">
                  <span className="flex items-center gap-1"><Youtube className="w-2.5 h-2.5 text-red-500" /> {pA.socialUrl}</span>
                  <span className="text-indigo-500/80 dark:text-cyan-500/80">{arenaStats.followersA} FOLLOWERS</span>
               </div>
            </div>
          </div>

          {/* Logic Pot & Mode Select */}
          <div className="flex flex-col items-center gap-1 w-full md:w-1/4">
            <div className="flex items-center gap-3">
               <div className="text-center">
                  <span className="text-[8px] font-black text-slate-400 dark:text-indigo-400 uppercase tracking-[0.3em] mb-1 block">Truth Pot</span>
                  <span className="text-xl font-black text-amber-600 dark:text-amber-500 flex items-center justify-center gap-1">
                    <Coins className="w-4 h-4" /> {arenaStats.truthPot}
                  </span>
               </div>
               <div className="w-px h-8 bg-slate-200 dark:bg-indigo-500/20 mx-2" />
               <div className="flex flex-col items-center">
                  <span className="text-[8px] font-black text-slate-400 dark:text-indigo-400 uppercase tracking-widest mb-1 block">System Mode</span>
                  <div className="flex bg-slate-50 dark:bg-slate-800 rounded-md p-0.5 border border-slate-200 dark:border-indigo-500/20">
                    <button onClick={() => setAnalysisMode(AnalysisMode.ARENA)} className={`px-2.5 py-1 rounded text-[8px] font-black uppercase transition-all ${analysisMode === AnalysisMode.ARENA ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 dark:text-slate-500'}`}>1v1 Arena</button>
                    <button onClick={() => setAnalysisMode(AnalysisMode.MONOLOGUE)} className={`px-2.5 py-1 rounded text-[8px] font-black uppercase transition-all ${analysisMode === AnalysisMode.MONOLOGUE ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 dark:text-slate-500'}`}>Solo Audit</button>
                  </div>
               </div>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1 bg-indigo-50 dark:bg-indigo-500/10 rounded-full border border-indigo-100 dark:border-indigo-500/30 mt-1">
               <Zap className="w-2 h-2 text-indigo-500 dark:text-indigo-400 animate-pulse" />
               <span className="text-[8px] font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-widest">{arenaStats.award}</span>
            </div>
          </div>

          {/* Participant B Card */}
          <div className="flex items-center gap-4 w-full md:w-1/3 flex-row-reverse text-right group">
            <div className="relative shrink-0">
              {analysisMode === AnalysisMode.ARENA ? (
                <img src={pB.thumbnail} className="w-14 h-14 rounded-full object-cover ring-2 ring-pink-500/20 dark:ring-magenta-500/50 shadow-md transition-all group-hover:scale-105" alt="pB" />
              ) : (
                <div className="w-14 h-14 rounded-full bg-emerald-50 dark:bg-emerald-500/10 flex items-center justify-center border-2 border-emerald-200 dark:border-emerald-500/50">
                  <ShieldCheck className="w-8 h-8 text-emerald-500" />
                </div>
              )}
              <div className={`absolute -bottom-1 -left-1 text-white text-[8px] font-black px-1.5 rounded-sm shadow-lg border border-white/20 ${analysisMode === AnalysisMode.ARENA ? 'bg-pink-600 dark:bg-fuchsia-600' : 'bg-emerald-600'}`}>
                {analysisMode === AnalysisMode.ARENA ? `LVL ${pB.level}` : 'DATA'}
              </div>
            </div>
            <div className="flex-1 min-w-0">
               <div className="flex items-center justify-between mb-1 flex-row-reverse">
                 <span className={`text-[10px] font-black uppercase tracking-widest truncate ml-2 ${analysisMode === AnalysisMode.ARENA ? 'text-pink-500 dark:text-fuchsia-400' : 'text-emerald-600 dark:text-emerald-400'}`}>
                  {analysisMode === AnalysisMode.ARENA ? pB.name : 'FACTUAL MATRIX'}
                 </span>
                 <span className={`text-xs font-black ${analysisMode === AnalysisMode.ARENA ? 'text-pink-600 dark:text-fuchsia-500' : 'text-emerald-600 dark:text-emerald-500'}`}>
                  {arenaStats.pointsB} PTS
                 </span>
               </div>
               <div className="w-full h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden flex flex-row-reverse">
                  <div className={`h-full ${analysisMode === AnalysisMode.ARENA ? 'bg-pink-500 dark:bg-fuchsia-500' : 'bg-emerald-500'} transition-all duration-1000 shadow-md`} style={{ width: `${arenaStats.pointsB}%` }} />
               </div>
               <div className="flex justify-between items-center mt-1 text-[8px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-tighter flex-row-reverse">
                  <span className="flex items-center gap-1">
                    {analysisMode === AnalysisMode.ARENA ? (
                      <><Instagram className="w-2.5 h-2.5 text-pink-500" /> {pB.socialUrl}</>
                    ) : (
                      <><Binary className="w-2.5 h-2.5 text-emerald-500" /> 2025 Deep Calibration</>
                    )}
                  </span>
                  <span className={analysisMode === AnalysisMode.ARENA ? 'text-pink-500 dark:text-fuchsia-400' : 'text-emerald-500'}>
                    {analysisMode === AnalysisMode.ARENA ? `${arenaStats.followersB} FOLLOWERS` : 'KNOWLEDGE RAG'}
                  </span>
               </div>
            </div>
          </div>

        </div>
      </header>

      {/* 2. Calibration Workspace */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        
        {/* Sidebar: Deep Logic Calibration */}
        <aside className="w-full lg:w-80 shrink-0 border-r border-slate-200 dark:border-indigo-500/10 bg-white dark:bg-slate-900/50 overflow-y-auto p-5 space-y-6 no-scrollbar">
          
          {/* Creator Profile Editor */}
          <div className="space-y-4">
             <div className="flex items-center gap-2 mb-2"><Users className="w-4 h-4 text-indigo-500 dark:text-indigo-400" /><h3 className="text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-widest">Creator Profiles</h3></div>
             
             <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-indigo-500/10 space-y-3">
               <div className="flex items-center justify-between"><span className="text-[9px] font-black text-indigo-600 dark:text-cyan-500 uppercase tracking-widest">Subject Alpha</span><Youtube className="w-3 h-3 text-red-600" /></div>
               <input value={pA.name} onChange={e => setPA({...pA, name: e.target.value})} className="w-full text-xs font-bold bg-transparent border-b border-slate-200 dark:border-indigo-500/20 outline-none pb-1 focus:border-indigo-500" />
               <input value={pA.socialUrl} onChange={e => setPA({...pA, socialUrl: e.target.value})} className="w-full text-[10px] bg-transparent outline-none text-slate-400 dark:text-slate-500 font-mono" />
               <div className="flex gap-2">
                 <div className="flex-1 bg-white dark:bg-black/40 rounded p-1.5 border border-slate-100 dark:border-indigo-500/10">
                   <label className="text-[8px] block font-black text-slate-400 dark:text-slate-600 uppercase">Followers</label>
                   <input value={pA.followers} onChange={e => setPA({...pA, followers: e.target.value})} className="w-full text-[10px] font-bold bg-transparent outline-none text-indigo-600 dark:text-cyan-500" />
                 </div>
                 <div className="w-16 bg-white dark:bg-black/40 rounded p-1.5 border border-slate-100 dark:border-indigo-500/10">
                   <label className="text-[8px] block font-black text-slate-400 dark:text-slate-600 uppercase">Level</label>
                   <input type="number" value={pA.level} onChange={e => setPA({...pA, level: parseInt(e.target.value)})} className="w-full text-[10px] font-bold bg-transparent outline-none text-indigo-600 dark:text-cyan-500 text-center" />
                 </div>
               </div>
             </div>

             {analysisMode === AnalysisMode.ARENA && (
               <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-indigo-500/10 space-y-3">
                 <div className="flex items-center justify-between"><span className="text-[9px] font-black text-pink-600 dark:text-fuchsia-500 uppercase tracking-widest">Subject Beta</span><Instagram className="w-3 h-3 text-pink-600" /></div>
                 <input value={pB.name} onChange={e => setPB({...pB, name: e.target.value})} className="w-full text-xs font-bold bg-transparent border-b border-slate-200 dark:border-indigo-500/20 outline-none pb-1 focus:border-pink-500" />
                 <input value={pB.socialUrl} onChange={e => setPB({...pB, socialUrl: e.target.value})} className="w-full text-[10px] bg-transparent outline-none text-slate-400 dark:text-slate-500 font-mono" />
                 <div className="flex gap-2">
                   <div className="flex-1 bg-white dark:bg-black/40 rounded p-1.5 border border-slate-100 dark:border-indigo-500/10">
                     <label className="text-[8px] block font-black text-slate-400 dark:text-slate-600 uppercase">Followers</label>
                     <input value={pB.followers} onChange={e => setPB({...pB, followers: e.target.value})} className="w-full text-[10px] font-bold bg-transparent outline-none text-pink-600 dark:text-fuchsia-500" />
                   </div>
                   <div className="w-16 bg-white dark:bg-black/40 rounded p-1.5 border border-slate-100 dark:border-indigo-500/10">
                     <label className="text-[8px] block font-black text-slate-400 dark:text-slate-600 uppercase">Level</label>
                     <input type="number" value={pB.level} onChange={e => setPB({...pB, level: parseInt(e.target.value)})} className="w-full text-[10px] font-bold bg-transparent outline-none text-pink-600 dark:text-fuchsia-500 text-center" />
                   </div>
                 </div>
               </div>
             )}
          </div>

          {/* Logic Calibration Controls */}
          <div className="pt-4 border-t border-slate-200 dark:border-indigo-500/10 space-y-4">
             <div className="flex items-center gap-2 mb-2"><Globe className="w-4 h-4 text-indigo-500 dark:text-indigo-400" /><h3 className="text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-widest">Logic Calibration</h3></div>
             
             <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <label className="text-[8px] font-black text-slate-400 dark:text-slate-600 uppercase">Region</label>
                  <select value={country} onChange={e => setCountry(e.target.value)} className="w-full text-[10px] bg-slate-50 dark:bg-black/40 border border-slate-200 dark:border-indigo-500/20 rounded-lg p-2 outline-none dark:text-slate-300">
                    {COUNTRIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[8px] font-black text-slate-400 dark:text-slate-600 uppercase">Year</label>
                  <select value={year} onChange={e => setYear(e.target.value)} className="w-full text-[10px] bg-slate-50 dark:bg-black/40 border border-slate-200 dark:border-indigo-500/20 rounded-lg p-2 outline-none dark:text-slate-300">
                    {YEARS.map(y => <option key={y} value={y}>{y}</option>)}
                  </select>
                </div>
             </div>

             <div className="space-y-3">
                <div className="space-y-1">
                  <label className="text-[8px] font-black text-slate-400 dark:text-slate-600 uppercase">Target Demography</label>
                  <select value={demography} onChange={e => setDemography(e.target.value)} className="w-full text-[10px] bg-slate-50 dark:bg-black/40 border border-slate-200 dark:border-indigo-500/20 rounded-lg p-2 outline-none dark:text-slate-300">
                    {DEMOGRAPHICS.map(d => <option key={d} value={d}>{d}</option>)}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[8px] font-black text-slate-400 dark:text-slate-600 uppercase">Arbiter Persona</label>
                  <select value={persona} onChange={e => setPersona(e.target.value)} className="w-full text-[10px] bg-slate-50 dark:bg-black/40 border border-slate-200 dark:border-indigo-500/20 rounded-lg p-2 outline-none dark:text-slate-300">
                    {PERSONAS.map(p => <option key={p} value={p}>{p}</option>)}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[8px] font-black text-slate-400 dark:text-slate-600 uppercase">Logic Rigour</label>
                  <select value={logicStyle} onChange={e => setLogicStyle(e.target.value)} className="w-full text-[10px] bg-slate-50 dark:bg-black/40 border border-slate-200 dark:border-indigo-500/20 rounded-lg p-2 outline-none dark:text-slate-300">
                    {LOGIC_STYLES.map(l => <option key={l} value={l}>{l}</option>)}
                  </select>
                </div>
                <div className="space-y-2 pt-2">
                  <div className="flex justify-between items-center text-[9px] font-black text-slate-500 dark:text-slate-400 uppercase"><span>Margin of Error</span><span className="text-indigo-600 dark:text-indigo-400">{marginOfError}%</span></div>
                  <input type="range" min="0" max="50" step="1" value={marginOfError} onChange={e => setMarginOfError(parseInt(e.target.value))} className="w-full h-1 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500" />
                </div>
             </div>
          </div>

          {/* Neural RAG Binding - UPDATED with specific examples and file placeholders */}
          <div className="pt-4 border-t border-slate-200 dark:border-indigo-500/10 space-y-4">
             <div className="flex items-center gap-2 mb-2"><ClipboardList className="w-4 h-4 text-indigo-500 dark:text-indigo-400" /><h3 className="text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-widest">Knowledge Ingestion</h3></div>
             
             <div className="space-y-2">
               <label className="flex items-center gap-1.5 text-[8px] font-black text-slate-400 dark:text-slate-600 uppercase tracking-wider">
                  <LinkIcon className="w-2.5 h-2.5" /> Reference URLs
               </label>
               <textarea 
                  value={ragUrls} 
                  onChange={e => setRagUrls(e.target.value)} 
                  className="w-full bg-slate-50 dark:bg-black/40 text-[10px] font-mono border border-slate-200 dark:border-indigo-500/20 rounded-xl p-3 h-20 outline-none text-slate-700 dark:text-slate-400 focus:border-indigo-500 dark:focus:border-indigo-500/50 transition-all shadow-inner" 
                  placeholder={"https://ipcc.ch/report/...\nhttps://fbref.com/en/..."} 
               />
             </div>

             <div className="space-y-2">
               <label className="flex items-center gap-1.5 text-[8px] font-black text-slate-400 dark:text-slate-600 uppercase tracking-wider">
                  <FileText className="w-2.5 h-2.5" /> Files / Transcripts
               </label>
               <div 
                  onClick={() => contextInputRef.current?.click()} 
                  className="p-4 border-2 border-dashed border-slate-200 dark:border-indigo-500/10 rounded-2xl bg-slate-50 dark:bg-black/20 hover:bg-slate-100 dark:hover:bg-black/40 transition-all flex flex-col items-center justify-center cursor-pointer group"
               >
                  <FileUp className="w-5 h-5 text-slate-400 dark:text-slate-600 group-hover:text-indigo-500 mb-2" />
                  <span className="text-[9px] font-black text-slate-400 dark:text-slate-600 uppercase tracking-widest group-hover:text-slate-600 dark:group-hover:text-slate-400">
                    Drop .pdf / .txt / .vtt here
                  </span>
                  <input ref={contextInputRef} type="file" className="hidden" multiple onChange={handleContextUpload} />
               </div>
               {contextFiles.length > 0 && (
                 <div className="flex flex-wrap gap-1 mt-2">
                   {contextFiles.slice(0, 3).map((f, i) => (
                     <span key={i} className="text-[7px] font-bold bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 px-1.5 py-0.5 rounded border border-indigo-100 dark:border-indigo-500/20 truncate max-w-[80px]">{f}</span>
                   ))}
                   {contextFiles.length > 3 && <span className="text-[7px] font-bold text-slate-400">+{contextFiles.length - 3} more</span>}
                 </div>
               )}
             </div>
          </div>

        </aside>

        {/* Main Feed: The Crystal Box Analysis */}
        <main className="flex-1 flex flex-col min-w-0 p-6 space-y-6 overflow-y-auto no-scrollbar bg-slate-100/50 dark:bg-slate-950/50">
          
          <div className="grid lg:grid-cols-[1fr_350px] gap-6">
            <div className="space-y-6">
               {/* Analysis Input Zone */}
               <div className="bg-white dark:bg-slate-900/50 rounded-3xl border border-slate-200 dark:border-indigo-500/10 p-6 shadow-xl dark:shadow-2xl relative overflow-hidden">
                  <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
                    <div className="space-y-3">
                       <h4 className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest flex items-center gap-2"><Monitor className="w-3 h-3" /> Input Stream</h4>
                       <div onClick={() => fileInputRef.current?.click()} className="aspect-video bg-slate-50 dark:bg-black/40 rounded-2xl border border-slate-200 dark:border-indigo-500/20 flex flex-col items-center justify-center cursor-pointer hover:border-indigo-400 dark:hover:border-indigo-500/50 transition-all overflow-hidden relative shadow-inner group">
                         {video ? <video src={video} className="w-full h-full object-contain" controls /> : (
                           <><div className="w-12 h-12 bg-white dark:bg-white/5 rounded-full flex items-center justify-center mb-2 shadow-sm dark:shadow-none group-hover:scale-110 transition-transform"><History className="w-5 h-5 text-indigo-500" /></div><p className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">Neural Simulation Idle</p></>
                         )}
                         <input ref={fileInputRef} type="file" className="hidden" accept="video/*" onChange={handleVideoUpload} />
                       </div>
                    </div>
                    <div className="flex flex-col gap-5">
                       <h4 className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest flex items-center gap-2"><Gavel className="w-3.5 h-3.5 text-indigo-500" /> Arbiter Tuning</h4>
                       <textarea value={prompt} onChange={e => setPrompt(e.target.value)} className="flex-1 w-full bg-slate-50 dark:bg-black/40 border border-slate-200 dark:border-indigo-500/20 rounded-2xl p-4 text-[11px] font-medium leading-relaxed outline-none focus:ring-2 focus:ring-indigo-500/30 resize-none text-slate-700 dark:text-slate-300 shadow-inner" placeholder="Execute specific syllogistic query..." />
                       <button onClick={runAnalysis} disabled={loading} className="w-full bg-indigo-600 hover:bg-indigo-700 text-white flex items-center justify-center gap-3 py-4 rounded-2xl font-black text-xs uppercase tracking-[0.3em] shadow-lg active:scale-[0.98] transition-all disabled:opacity-50 group">
                         {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <ShieldCheck className="w-5 h-5 group-hover:rotate-12 transition-transform" />} Execute Audit
                       </button>
                    </div>
                  </div>
               </div>

               {/* Cognitive Output Area */}
               <div className="bg-white dark:bg-slate-900/50 rounded-3xl border border-slate-200 dark:border-indigo-500/10 flex flex-col overflow-hidden min-h-[500px] shadow-xl dark:shadow-2xl relative">
                  <div className="px-6 py-4 border-b border-slate-100 dark:border-indigo-500/10 bg-slate-50 dark:bg-black/20 flex justify-between items-center">
                     <div className="flex items-center gap-2"><BarChart3 className="w-4 h-4 text-indigo-500" /><h3 className="text-[10px] font-black text-slate-500 dark:text-slate-500 uppercase tracking-widest">Logical Adjudication Matrix</h3></div>
                     <div className="flex items-center gap-3">
                        <span className="text-[8px] font-black bg-emerald-100 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-500 px-3 py-1 rounded-full border border-emerald-200 dark:border-emerald-500/20 uppercase tracking-widest">Truth Density: {reliability}%</span>
                        <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
                     </div>
                  </div>
                  <div className="flex-1 p-8 font-mono text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed overflow-y-auto no-scrollbar selection:bg-indigo-500/30">
                    {loading ? (
                       <div className="h-full flex flex-col items-center justify-center gap-8">
                          <div className="relative">
                             <Brain className="w-16 h-16 text-indigo-500 animate-[pulse_1.5s_ease-in-out_infinite]" />
                             <div className="absolute inset-0 border-2 border-indigo-500/30 rounded-full animate-ping" />
                          </div>
                          <p className="text-[10px] font-black uppercase tracking-[0.5em] text-indigo-500 animate-pulse">Extracting Toulmin Nodes</p>
                       </div>
                    ) : result ? (
                       <div className="prose dark:prose-invert prose-slate prose-xs max-w-none">
                         {result.split(/POINTS_A|POINTS_B|TRUTH_POT|FOLLOWERS_A|FOLLOWERS_B|AWARD/)[0]}
                         <div className="mt-8 pt-8 border-t border-slate-100 dark:border-indigo-500/10">
                            {result.substring(result.indexOf('Verdict:'))}
                         </div>
                       </div>
                    ) : (
                       <div className="h-full flex flex-col items-center justify-center gap-4 opacity-30">
                          <Binary className="w-12 h-12 text-slate-400 dark:text-slate-600" />
                          <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Awaiting Simulation Data</p>
                       </div>
                    )}
                  </div>
               </div>
            </div>

            {/* Right: Active Fallacy Console & Score Rubrics */}
            <aside className="space-y-6">
               <div className="bg-white dark:bg-slate-900/80 rounded-3xl border border-slate-200 dark:border-indigo-500/10 overflow-hidden flex flex-col h-[350px] shadow-lg dark:shadow-2xl">
                  <div className="px-5 py-3 border-b border-slate-100 dark:border-indigo-500/10 bg-slate-50 dark:bg-black/40 flex items-center justify-between">
                     <h4 className="text-[10px] font-black text-slate-500 dark:text-slate-500 uppercase tracking-widest flex items-center gap-2"><Activity className="w-3 h-3 text-red-500" /> Active Fallacy Log</h4>
                     <span className="text-[8px] font-black text-red-500 uppercase animate-pulse">LIVE AUDIT</span>
                  </div>
                  <div className="flex-1 p-5 overflow-y-auto space-y-4 no-scrollbar">
                     {result && result.includes('Fallacy Log') ? result.match(/Fallacy Log:([\s\S]+?)(Reliability Score|Query|$)/)?.[1].split('\n').filter(l => l.trim().length > 5).map((line, i) => (
                        <div key={i} className="flex gap-4 animate-in slide-in-from-right-2 duration-300">
                           <div className="w-1.5 h-1.5 rounded-full bg-red-500 mt-1.5 shrink-0 shadow-[0_0_8px_rgba(239,68,68,0.8)]" />
                           <div className="space-y-1">
                              <p className="text-[9px] font-black text-red-500 uppercase tracking-tighter">Syllogistic Violation</p>
                              <p className="text-[10px] font-medium text-slate-500 dark:text-slate-400 leading-tight bg-red-50 dark:bg-red-500/5 p-2 rounded-lg border border-red-100 dark:border-red-500/10">{line.trim().replace(/^[-*]\s*/, '')}</p>
                           </div>
                        </div>
                     )) : <p className="text-[10px] text-slate-400 dark:text-slate-600 italic font-medium text-center py-20 opacity-50">Zero violations registered in current buffer.</p>}
                  </div>
               </div>

               {/* WTS Metrics Rubric */}
               <div className="bg-white dark:bg-slate-900/80 rounded-3xl border border-slate-200 dark:border-indigo-500/10 p-6 space-y-6 shadow-lg dark:shadow-2xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/5 rounded-full -mr-12 -mt-12" />
                  <h4 className="text-[10px] font-black text-slate-500 dark:text-slate-500 uppercase tracking-widest flex items-center gap-2"><Scale className="w-3 h-3 text-indigo-500" /> WTS Calibration</h4>
                  <div className="space-y-6">
                     {[
                       { label: 'Content / Logic', color: 'indigo', darkColor: 'cyan', val: weights.logic }, 
                       { label: 'Style / Rhetoric', color: 'pink', darkColor: 'magenta', val: weights.rhetoric }, 
                       { label: 'Strategy / Evidence', color: 'emerald', darkColor: 'emerald', val: weights.evidence }
                     ].map(m => (
                        <div key={m.label} className="space-y-2">
                           <div className="flex justify-between items-end">
                              <span className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-tighter">{m.label}</span>
                              <span className={`text-xs font-black ${m.darkColor === 'magenta' ? 'text-pink-600 dark:text-[#bd00ff]' : m.darkColor === 'emerald' ? 'text-emerald-600 dark:text-emerald-500' : 'text-indigo-600 dark:text-cyan-500'}`}>{m.val}%</span>
                           </div>
                           <div className="w-full h-1 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden shadow-inner">
                              <div 
                                className={`h-full transition-all duration-1000 shadow-sm`} 
                                style={{ 
                                  width: `${m.val}%`, 
                                  backgroundColor: m.darkColor === 'magenta' ? '#bd00ff' : m.darkColor === 'emerald' ? '#10b981' : '#6366f1' 
                                }} 
                              />
                           </div>
                        </div>
                     ))}
                  </div>
               </div>
            </aside>
          </div>

          {error && <div className="p-5 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-500/20 rounded-2xl flex items-center gap-4 text-red-600 dark:text-red-500 text-[10px] font-black uppercase tracking-widest animate-in shake"><AlertCircle className="w-6 h-6 shrink-0" /> Engine Fault: {error}</div>}
        </main>
      </div>
      
      <style>{`
        .scrollbar-hide::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        .prose-xs { font-size: 0.75rem; line-height: 1.7; }
        .prose-xs h1, .prose-xs h2, .prose-xs h3 { text-transform: uppercase; font-weight: 900; letter-spacing: 0.1em; margin-bottom: 0.5em; }
        .dark .prose-xs { color: #94a3b8; }
        .dark .prose-xs h1, .dark .prose-xs h2, .dark .prose-xs h3 { color: #f1f5f9; }
        .dark .prose-xs strong { color: #f1f5f9; }
        @keyframes pulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.7; transform: scale(0.95); }
        }
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-5px); }
          75% { transform: translateX(5px); }
        }
      `}</style>
    </div>
  );
};
