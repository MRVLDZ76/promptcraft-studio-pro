
import React from 'react';
import { PromptState, QAIssue } from '../types';
import { Copy, RotateCcw, Wand2, CheckCircle2, AlertTriangle, Info, Hammer } from 'lucide-react';

interface Props {
  prompt: string;
  onPolish: () => Promise<void>;
  loading: boolean;
  issues: QAIssue[];
  onApplyFixes: () => void;
  onUndo: () => void;
  onRedo: () => void;
  canUndo: boolean;
  canRedo: boolean;
}

export const OutputEngine: React.FC<Props> = ({ 
  prompt, onPolish, loading, issues, onApplyFixes, onUndo, onRedo, canUndo, canRedo 
}) => {
  const [copying, setCopying] = React.useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(prompt);
    setCopying(true);
    setTimeout(() => setCopying(false), 2000);
  };

  const score = Math.max(0, 100 - issues.reduce((acc, it) => acc + (it.severity === 'warn' ? 15 : 5), 0));

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden group dark:bg-slate-900 dark:border-slate-800">
        <div className="border-b border-slate-100 bg-slate-50 px-4 py-2 flex justify-between items-center dark:bg-slate-800 dark:border-slate-700">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Final Prompt</span>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono text-slate-400">{prompt.length} chars</span>
            <button onClick={onUndo} disabled={!canUndo} className="p-1.5 text-slate-400 hover:text-indigo-600 disabled:opacity-30"><RotateCcw className="w-3.5 h-3.5" /></button>
            <button onClick={handleCopy} className="p-1.5 text-slate-400 hover:text-indigo-600">
              {copying ? <CheckCircle2 className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>
        <textarea 
          readOnly 
          value={prompt}
          className="w-full h-40 p-5 text-sm text-slate-700 font-mono resize-none focus:outline-none bg-transparent dark:text-slate-300" 
        />
      </div>

      <button 
        onClick={onPolish}
        disabled={loading}
        className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white py-3 px-4 rounded-lg font-medium shadow-md transition-all active:scale-[0.98] disabled:opacity-50"
      >
        <Wand2 className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
        <span>{loading ? 'Polishing...' : 'AI Enhance & Polish'}</span>
      </button>

      {/* Prompt QA */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden dark:bg-slate-900 dark:border-slate-800">
        <div className="border-b border-slate-100 bg-slate-50 px-4 py-2 flex justify-between items-center dark:bg-slate-800 dark:border-slate-700">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Prompt QA</span>
          <div className="flex items-center gap-2">
            <span className={`text-[10px] font-bold ${score > 80 ? 'text-green-500' : 'text-amber-500'}`}>Score: {score}</span>
            <button onClick={onApplyFixes} className="text-[10px] bg-white border border-slate-200 px-2 py-1 rounded shadow-sm hover:bg-slate-50 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-300">
              <Hammer className="w-3 h-3 inline mr-1" /> Quick Fix
            </button>
          </div>
        </div>
        <div className="p-4 space-y-3">
          {issues.length === 0 ? (
            <div className="text-sm text-slate-500 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-green-500" />
              <span>Prompt is clean and optimized.</span>
            </div>
          ) : (
            issues.map((it, i) => (
              <div key={i} className="flex gap-3 p-2 rounded-lg bg-slate-50 dark:bg-slate-800/50">
                {it.severity === 'warn' ? <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" /> : <Info className="w-4 h-4 text-indigo-500 shrink-0 mt-0.5" />}
                <div className="min-w-0">
                  <div className="text-xs font-bold text-slate-700 dark:text-slate-200">{it.title}</div>
                  <div className="text-[10px] text-slate-500 dark:text-slate-400">{it.detail}</div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
