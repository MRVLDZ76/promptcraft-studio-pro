
import { GoogleGenAI, Type } from "@google/genai";
import { PromptState, SequenceSegment } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const polishPrompt = async (state: PromptState, currentPrompt: string): Promise<string> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `You are an expert prompt engineer. Improve this prompt for maximum visual quality, focusing on lighting, textures, and composition. Keep it as a single coherent paragraph. Original: ${currentPrompt}`,
    config: {
      temperature: 0.8,
      topP: 0.95,
    },
  });
  return response.text?.trim() || currentPrompt;
};

export const generateSequence = async (narrative: string, totalSec: number, clipLen: number): Promise<SequenceSegment[]> => {
  const count = Math.ceil(totalSec / clipLen);
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Create a video sequence plan based on this Narrative Arc: "${narrative}".
    Split it into ${count} sequential clips of ${clipLen} seconds each.
    Focus on narrative flow and cinematic style.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          segments: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.NUMBER },
                seconds: { type: Type.NUMBER },
                action: { type: Type.STRING },
                prompt: { type: Type.STRING }
              },
              required: ['id', 'seconds', 'action', 'prompt']
            }
          }
        },
        required: ['segments']
      }
    }
  });

  const json = JSON.parse(response.text || '{"segments": []}');
  return json.segments;
};

export const editImageWithGemini = async (imageData: string, editPrompt: string): Promise<string> => {
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: 'image/png',
            data: imageData.split(',')[1],
          },
        },
        {
          text: editPrompt,
        },
      ],
    },
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  throw new Error("No image was returned by the model.");
};
