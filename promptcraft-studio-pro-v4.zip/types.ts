
export enum Mode {
  IMAGE = 'image',
  VIDEO = 'video',
  SEQUENCE = 'sequence',
  EDIT = 'edit'
}

export interface VisualIngredient {
  id: string;
  label: string;
  value: string;
  desc: string;
}

export interface PromptState {
  subject: string;
  negative: string;
  aspect: string;
  model: string;
  style: {
    cam: string;
    light: string[];
    film: string;
  };
  scene: {
    setting: string;
    action: string;
    composition: string;
    mood: string;
    color: string;
  };
  detailLevel: 'compact' | 'detailed' | 'ultra';
  customIngredients: string[];
  video: {
    move: string;
    dur: string;
  };
}

export interface Character {
  id: string;
  name: string;
  text: string;
}

export interface SequenceSegment {
  id: number;
  seconds: number;
  action: string;
  prompt: string;
}

export interface QAIssue {
  severity: 'warn' | 'info';
  title: string;
  detail: string;
  fixId: string | null;
}
